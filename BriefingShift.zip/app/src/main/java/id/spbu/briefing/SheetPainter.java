package id.spbu.briefing;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

/** Menggambar hasil Layout ke Canvas (pratinjau) dan ke PDF A4 vektor 1 halaman. */
public class SheetPainter {
    static final Paint MR = new Paint(Paint.ANTI_ALIAS_FLAG);
    static final Paint MB = new Paint(Paint.ANTI_ALIAS_FLAG);
    static {
        MR.setTypeface(Typeface.create(Typeface.SERIF, Typeface.NORMAL));
        MB.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
        MR.setTextSize(100f);
        MB.setTextSize(100f);
    }

    public static Layout.Measurer measurer() {
        return new Layout.Measurer() {
            public float width(String t, boolean bold, float size) {
                return (bold ? MB : MR).measureText(t) * size / 100f;
            }
        };
    }

    public static Layout.Result layout(Model m) {
        return Layout.fit(m, measurer());
    }

    public static void draw(Canvas c, Layout.Result r) {
        Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        line.setStyle(Paint.Style.STROKE);
        line.setColor(Color.rgb(51, 51, 51));
        line.setStrokeWidth(0.6f);
        Paint txR = new Paint(Paint.ANTI_ALIAS_FLAG);
        txR.setTypeface(Typeface.create(Typeface.SERIF, Typeface.NORMAL));
        Paint txB = new Paint(Paint.ANTI_ALIAS_FLAG);
        txB.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
        Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
        Paint ln = new Paint(Paint.ANTI_ALIAS_FLAG);
        ln.setStyle(Paint.Style.STROKE);
        ln.setStrokeWidth(0.5f);
        for (Layout.Op o : r.ops) {
            if (o.k.equals("rect")) {
                c.drawRect(o.x, o.y, o.x + o.w, o.y + o.h, line);
            } else if (o.k.equals("line")) {
                ln.setColor(o.dash ? Color.rgb(102, 102, 102) : Color.BLACK);
                ln.setPathEffect(o.dash ? new DashPathEffect(new float[]{1.5f, 1.5f}, 0f) : null);
                c.drawLine(o.x1, o.y1, o.x2, o.y2, ln);
            } else if (o.k.equals("text")) {
                Paint p = o.b ? txB : txR;
                p.setTextSize(o.size);
                int g = Math.round(o.col * 255f);
                p.setColor(Color.rgb(g, g, g));
                c.drawText(o.t, o.x, o.y + o.size * 0.88f, p);
            } else if (o.k.equals("img")) {
                Bitmap bmp = (Bitmap) o.a.cache;
                if (bmp == null) {
                    bmp = BitmapFactory.decodeByteArray(o.a.bytes, 0, o.a.bytes.length);
                    o.a.cache = bmp;
                }
                if (bmp != null) {
                    RectF dst = new RectF(o.x, o.y, o.x + o.w, o.y + o.h);
                    if (o.cover) {
                        float bw = bmp.getWidth(), bh = bmp.getHeight();
                        float s = Math.max(o.w / bw, o.h / bh);
                        float sw = o.w / s, sh = o.h / s;
                        Rect src = new Rect(Math.round((bw - sw) / 2f), Math.round((bh - sh) / 2f),
                            Math.round((bw + sw) / 2f), Math.round((bh + sh) / 2f));
                        c.drawBitmap(bmp, src, dst, bp);
                    } else {
                        c.drawBitmap(bmp, null, dst, bp);
                    }
                }
            }
        }
    }

    /** Pratinjau bitmap selebar widthPx. */
    public static Bitmap preview(Layout.Result r, int widthPx) {
        float k = widthPx / Layout.PW;
        Bitmap bmp = Bitmap.createBitmap(widthPx, Math.round(Layout.PH * k), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        c.drawColor(Color.WHITE);
        c.scale(k, k);
        draw(c, r);
        return bmp;
    }

    public static byte[] pdf(Layout.Result r) throws IOException {
        PdfDocument doc = new PdfDocument();
        PdfDocument.Page page = doc.startPage(new PdfDocument.PageInfo.Builder(595, 842, 1).create());
        draw(page.getCanvas(), r);
        doc.finishPage(page);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        doc.writeTo(bo);
        doc.close();
        return bo.toByteArray();
    }
}
