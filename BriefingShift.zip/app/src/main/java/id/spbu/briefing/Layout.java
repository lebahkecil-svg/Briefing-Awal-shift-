package id.spbu.briefing;

import java.util.ArrayList;
import java.util.List;

/** Mesin tata letak lembar A4 (port dari buatPdf). Tanpa kelas Android. Satuan: poin. */
public class Layout {
    public static final float PW = 595.28f, PH = 841.89f, MX = 28f, MY = 28f;
    static final float PX = 4f, PY = 3f;

    public interface Measurer { float width(String t, boolean bold, float size); }

    public static class Op {
        public String k; // rect, text, img, line
        public float x, y, w, h, x1, y1, x2, y2, size, col;
        public String t;
        public boolean b, dash, cover;
        public Model.Img a;
    }

    public static class Result {
        public List<Op> ops = new ArrayList<>();
        public float H;
        public float scale = 1f;
    }

    static class Seg { String t; boolean b, u; Seg(String t, boolean b, boolean u) { this.t = t; this.b = b; this.u = u; } }
    static class Tok { String t; boolean b, u; float w; }
    static class Ln { List<Tok> toks = new ArrayList<>(); float w; }
    static class Wrapped { List<Ln> lines = new ArrayList<>(); float sp; }

    static class Item {
        String k = "p"; // p, gap, img, kv, stamp
        String label, value;
        List<Seg> segs;
        float size = 9.5f, before, indent, h, maxW, maxH, col, lw;
        String align, num;
        Model.Img a;
    }

    interface Custom {
        float measure(float w);
        void draw(float x, float y, float w, float h);
    }

    static class Cell {
        int c, r, cs, rs;
        List<Item> items;
        String va;
        Custom custom;
        float w, need;
    }

    public static float[] fitSize(float w, float h, float maxW, float maxH) {
        float s = Math.min(maxW / w, maxH / h);
        return new float[]{Math.max(1, Math.round(w * s)), Math.max(1, Math.round(h * s))};
    }

    final Model m;
    final Measurer me;
    final float CW;
    final List<Op> ops = new ArrayList<>();

    Layout(Model m, Measurer me, float CW) { this.m = m; this.me = me; this.CW = CW; }

    float wdt(String t, boolean b, float size) { return me.width(t, b, size); }

    Wrapped wrap(List<Seg> segs, float w, float size) {
        List<Tok> toks = new ArrayList<>();
        for (Seg sg : segs) {
            for (String word : sg.t.split(" ")) {
                if (!word.isEmpty()) { Tok k = new Tok(); k.t = word; k.b = sg.b; k.u = sg.u; toks.add(k); }
            }
        }
        float sp = wdt(" ", false, size);
        Wrapped out = new Wrapped();
        out.sp = sp;
        Ln cur = new Ln();
        for (Tok tk : toks) {
            if (wdt(tk.t, tk.b, size) <= w) { cur = push(out, cur, tk.t, tk.b, tk.u, w, size, sp); continue; }
            StringBuilder piece = new StringBuilder();
            for (int i = 0; i < tk.t.length(); i++) {
                String ch = String.valueOf(tk.t.charAt(i));
                if (piece.length() > 0 && wdt(piece + ch, tk.b, size) > w) {
                    cur = push(out, cur, piece.toString(), tk.b, tk.u, w, size, sp);
                    piece.setLength(0);
                }
                piece.append(ch);
            }
            if (piece.length() > 0) cur = push(out, cur, piece.toString(), tk.b, tk.u, w, size, sp);
        }
        if (!cur.toks.isEmpty() || out.lines.isEmpty()) out.lines.add(cur);
        return out;
    }

    Ln push(Wrapped out, Ln cur, String t, boolean b, boolean u, float w, float size, float sp) {
        float tw = wdt(t, b, size);
        if (!cur.toks.isEmpty() && cur.w + sp + tw > w) { out.lines.add(cur); cur = new Ln(); }
        cur.w += (cur.toks.isEmpty() ? 0 : sp) + tw;
        Tok k = new Tok(); k.t = t; k.b = b; k.u = u; k.w = tw;
        cur.toks.add(k);
        return cur;
    }

    float itemHeight(Item it, float w) {
        if (it.k.equals("gap")) return it.h;
        if (it.k.equals("img")) return it.before + fitSize(it.a.w, it.a.h, it.maxW, it.maxH)[1];
        if (it.k.equals("stamp")) return it.before + fitSize(it.a.w, it.a.h, it.maxW, it.maxH)[1] + 5f;
        if (it.k.equals("kv")) {
            float off = it.lw + wdt(":", true, it.size) + 3f;
            return wrap(S(it.value, false), w - off, it.size).lines.size() * it.size * 1.22f;
        }
        Wrapped r = wrap(it.segs, w - it.indent, it.size);
        return it.before + r.lines.size() * it.size * 1.22f;
    }

    float itemsHeight(List<Item> items, float w) {
        float s = 0;
        if (items != null) for (Item it : items) s += itemHeight(it, w);
        return s;
    }

    void drawItems(List<Item> items, float x, float y, float w) {
        float cy = y;
        for (Item it : items) {
            if (it.k.equals("gap")) { cy += it.h; continue; }
            if (it.k.equals("stamp")) {
                cy += it.before;
                float[] f = fitSize(it.a.w, it.a.h, it.maxW, it.maxH);
                float ix = x + (w - f[0]) / 2;
                Op o = new Op(); o.k = "img"; o.a = it.a; o.x = ix; o.y = cy; o.w = f[0]; o.h = f[1];
                ops.add(o);
                cy += f[1];
                float span = (Model.RETAIL_X1 - Model.RETAIL_X0) * f[0];
                float base = wdt(Model.SUB_LOGO, true, 10f);
                float sz = Math.max(3f, span / base * 10f);
                float tw = wdt(Model.SUB_LOGO, true, sz);
                float cx = ix + (Model.RETAIL_X0 + Model.RETAIL_X1) / 2 * f[0];
                text(Model.SUB_LOGO, cx - tw / 2, cy + 0.5f, sz, true, 0);
                cy += 5f;
                continue;
            }
            if (it.k.equals("kv")) {
                float off = it.lw + wdt(":", true, it.size) + 3f;
                Wrapped rv = wrap(S(it.value, false), w - off, it.size);
                text(it.label, x, cy, it.size, true, 0);
                text(":", x + it.lw, cy, it.size, true, 0);
                for (Ln ln : rv.lines) {
                    float cx = x + off;
                    for (Tok tk : ln.toks) { text(tk.t, cx, cy, it.size, false, 0); cx += tk.w + rv.sp; }
                    cy += it.size * 1.22f;
                }
                continue;
            }
            if (it.k.equals("img")) {
                cy += it.before;
                float[] f = fitSize(it.a.w, it.a.h, it.maxW, it.maxH);
                float ix = "c".equals(it.align) ? x + (w - f[0]) / 2 : x;
                Op o = new Op(); o.k = "img"; o.a = it.a; o.x = ix; o.y = cy; o.w = f[0]; o.h = f[1];
                ops.add(o);
                cy += f[1];
                continue;
            }
            Wrapped r = wrap(it.segs, w - it.indent, it.size);
            cy += it.before;
            if (it.num != null) text(it.num, x, cy, it.size, false, 0);
            for (Ln ln : r.lines) {
                float lx = x + it.indent;
                if ("c".equals(it.align)) lx = x + it.indent + (w - it.indent - ln.w) / 2;
                float cx = lx;
                for (Tok tk : ln.toks) {
                    text(tk.t, cx, cy, it.size, tk.b, it.col);
                    if (tk.u) line(cx, cy + it.size, cx + tk.w, cy + it.size, false);
                    cx += tk.w + r.sp;
                }
                cy += it.size * 1.22f;
            }
        }
    }

    void text(String t, float x, float y, float size, boolean b, float col) {
        Op o = new Op(); o.k = "text"; o.t = t; o.x = x; o.y = y; o.size = size; o.b = b; o.col = col;
        ops.add(o);
    }

    void line(float x1, float y1, float x2, float y2, boolean dash) {
        Op o = new Op(); o.k = "line"; o.x1 = x1; o.y1 = y1; o.x2 = x2; o.y2 = y2; o.dash = dash;
        ops.add(o);
    }

    // ---- pembuat item ----
    static Item P(List<Seg> segs, float size, String align, float before, float indent, String num) {
        Item i = new Item(); i.segs = segs; if (size > 0) i.size = size; i.align = align; i.before = before; i.indent = indent; i.num = num;
        return i;
    }
    static List<Seg> S(Object... a) {
        List<Seg> l = new ArrayList<>();
        for (int i = 0; i < a.length; i += 2) l.add(new Seg((String) a[i], (Boolean) a[i + 1], false));
        return l;
    }
    static Item T(String t, boolean b) { return P(S(t, b), 0, null, 0, 0, null); }
    static Item T(String t, boolean b, String align) { return P(S(t, b), 0, align, 0, 0, null); }
    static Item V(String label, String value) { return P(S(label, true, value, false), 0, null, 0, 0, null); }
    static Item KV(String label, String value, float lw) {
        Item i = new Item(); i.k = "kv"; i.label = label; i.value = value == null ? "" : value; i.lw = lw; return i;
    }
    static Item small(Item i, float size) { i.size = size; return i; }
    static Item ST(Model.Img a, float maxW, float maxH, float before) {
        Item i = new Item(); i.k = "stamp"; i.a = a; i.maxW = maxW; i.maxH = maxH; i.before = before; return i;
    }
    static Item G(float h) { Item i = new Item(); i.k = "gap"; i.h = h; return i; }
    static Item I(Model.Img a, float maxW, float maxH, String align, float before) {
        Item i = new Item(); i.k = "img"; i.a = a; i.maxW = maxW; i.maxH = maxH; i.align = align; i.before = before; return i;
    }
    static List<Item> L(Item... a) { List<Item> l = new ArrayList<>(); for (Item i : a) l.add(i); return l; }
    List<Item> linesOf(String text) {
        List<Item> l = new ArrayList<>();
        for (String x : (text == null ? "" : text).split("\n", -1)) l.add(T(x, false));
        return l;
    }
    static Cell C(int c, int r, int cs, int rs, List<Item> items, String va, Custom custom) {
        Cell k = new Cell(); k.c = c; k.r = r; k.cs = cs; k.rs = rs; k.items = items; k.va = va; k.custom = custom; return k;
    }
    static Cell C(int c, int r, int cs, int rs, List<Item> items) { return C(c, r, cs, rs, items, null, null); }

    float table(float y0, float[] fr, int nrows, float[] minH, List<Cell> cells) {
        float[] colX = new float[fr.length + 1];
        for (int i = 0; i < fr.length; i++) colX[i + 1] = colX[i] + fr[i] * CW;
        float[] rh = new float[nrows];
        for (int i = 0; i < nrows; i++) rh[i] = minH[Math.min(i, minH.length - 1)];
        for (Cell c : cells) {
            c.w = colX[c.c + c.cs] - colX[c.c];
            c.need = c.custom != null ? c.custom.measure(c.w) : itemsHeight(c.items, c.w - 2 * PX) + 2 * PY;
        }
        for (Cell c : cells) if (c.rs == 1) rh[c.r] = Math.max(rh[c.r], c.need);
        for (Cell c : cells) {
            if (c.rs == 1) continue;
            float sum = 0;
            for (int j = c.r; j < c.r + c.rs; j++) sum += rh[j];
            if (c.need > sum) {
                float extra = (c.need - sum) / c.rs;
                for (int j = c.r; j < c.r + c.rs; j++) rh[j] += extra;
            }
        }
        float[] rowY = new float[nrows + 1];
        for (int i = 0; i < nrows; i++) rowY[i + 1] = rowY[i] + rh[i];
        for (Cell c : cells) {
            float x = colX[c.c], y = y0 + rowY[c.r], h = rowY[c.r + c.rs] - rowY[c.r];
            Op o = new Op(); o.k = "rect"; o.x = x; o.y = y; o.w = c.w; o.h = h;
            ops.add(o);
            if (c.custom != null) { c.custom.draw(x, y, c.w, h); continue; }
            float used = itemsHeight(c.items, c.w - 2 * PX);
            float off = "c".equals(c.va) ? Math.max(0, (h - 2 * PY - used) / 2) : 0;
            drawItems(c.items, x + PX, y + PY + off, c.w - 2 * PX);
        }
        return rowY[nrows];
    }

    float build() {
        float cur = 0;
        text("SHIFT " + m.no, 0, 0, 12, true, 0);
        cur += 17;

        // Tabel 1
        Custom judulLogo = new Custom() {
            public float measure(float w) { return 46; }
            public void draw(float x, float y, float w, float h) {
                text("BRIEFING PERGANTIAN SHIFT", x + 6, y + h / 2 - 6, 11, true, 0);
                if (m.logo != null) {
                    float[] f = fitSize(m.logo.w, m.logo.h, 100, 34);
                    float lx = x + w - f[0] - 6;
                    Op o = new Op(); o.k = "img"; o.a = m.logo; o.x = lx; o.y = y + (h - f[1]) / 2; o.w = f[0]; o.h = f[1];
                    ops.add(o);
                    line(lx - 6, y + 6, lx - 6, y + h - 6, true);
                }
            }
        };
        float g1 = Math.max(wdt("Tanggal", true, 9.5f), wdt("Shift", true, 9.5f)) + 2f;
        float g2 = Math.max(wdt("Dipimpin", true, 9.5f), Math.max(wdt("KA. SHIFT", true, 9.5f), wdt("DICATAT", true, 9.5f))) + 2f;
        float g3 = Math.max(wdt("No. Dokumen", true, 9.5f), Math.max(wdt("Revisi", true, 9.5f), wdt("Disetujui", true, 9.5f))) + 2f;
        List<Item> disetujui = L(KV("Disetujui", "", g3));
        if (m.logoDisetujui && m.logo != null) disetujui.add(ST(m.logo, 100, 30, 6));
        disetujui.add(P(new ArrayList<>(java.util.Arrays.asList(new Seg("FERLIQ PONTUMIKA YUDITAMA", true, true))), 0, "c", 16, 0, null));
        disetujui.add(T("BUH SPBU", true, "c"));
        List<Cell> c1 = new ArrayList<>();
        c1.add(C(0, 0, 2, 2, null, null, judulLogo));
        c1.add(C(2, 0, 1, 1, L(small(KV("No. Dokumen", m.nomorDok, g3), 8.5f))));
        c1.add(C(2, 1, 1, 1, L(KV("Revisi", "", g3))));
        c1.add(C(0, 2, 1, 2, L(KV("Tanggal", m.tgl, g1), G(8), KV("Shift", m.no, g1))));
        c1.add(C(1, 2, 1, 1, L(KV("Dipimpin", m.dipimpin, g2))));
        c1.add(C(2, 2, 1, 3, disetujui));
        c1.add(C(1, 3, 1, 1, L(KV("KA. SHIFT", m.kashift, g2))));
        c1.add(C(0, 4, 1, 1, L(T("No SPBU: 31-10702", true), T("Lokasi SPBU: Jl. Samanhudi", true),
                P(S("COCO SAMANHUDI", true), 0, null, 0, 16, null))));
        c1.add(C(1, 4, 1, 1, L(KV("DICATAT", m.dicatat, g2))));
        cur += table(cur, new float[]{0.33f, 0.30f, 0.37f}, 5, new float[]{18}, c1);

        // Tabel 2
        List<Cell> c2 = new ArrayList<>();
        c2.add(C(0, 0, 1, 1, L(T("Topik Bahasan :", true))));
        c2.add(C(0, 1, 1, 1, linesOf(m.topik)));
        cur += table(cur, new float[]{1}, 2, new float[]{16, 34}, c2);

        // Tabel 3
        int n = m.jumlahBaris();
        List<Cell> c3 = new ArrayList<>();
        c3.add(C(0, 0, 2, 1, L(T("Peserta :", true))));
        c3.add(C(2, 0, 1, 1, L(T("Jabatan", true, "c"))));
        c3.add(C(3, 0, 2, 1, L(T("Tanda Tangan", true, "c"))));
        for (int i = 0; i < n; i++) {
            String[] p = i < m.peserta.size() ? m.peserta.get(i) : null;
            c3.add(C(0, i + 1, 1, 1, L(T(String.valueOf(i + 1), true, "c")), "c", null));
            c3.add(C(1, i + 1, 1, 1, L(T(p != null ? p[0] : "", false)), "c", null));
            c3.add(C(2, i + 1, 1, 1, L(T(p != null ? p[1] : "", false)), "c", null));
            if (i % 2 == 0) {
                if (i + 1 < n) {
                    c3.add(C(3, i + 1, 1, 2, null, null, sigCustom(i)));
                    c3.add(C(4, i + 1, 1, 2, null, null, sigCustom(i + 1)));
                } else {
                    // peserta terakhir (jumlah ganjil): kolom tanda tangan digabung, lebih lebar
                    c3.add(C(3, i + 1, 2, 1, null, null, sigCustom(i)));
                }
            }
        }
        float[] mh3 = new float[n + 1];
        mh3[0] = 16;
        for (int q = 1; q <= n; q++) mh3[q] = 30;
        if (n % 2 == 1) mh3[n] = 45; // 1,5 x tinggi normal
        cur += table(cur, new float[]{0.07f, 0.30f, 0.19f, 0.22f, 0.22f}, n + 1, mh3, c3);

        // Tabel 4
        cur += table(cur, new float[]{1}, 1, new float[]{16}, new ArrayList<>(java.util.Arrays.asList(C(0, 0, 1, 1, L(T("Ringkasan Materi Briefing :", true))))));

        // Tabel 5
        int nm = m.materi.size(), nh = m.hsse.size();
        int rows = nm + 1 + nh + 3;
        List<Cell> c5 = new ArrayList<>();
        for (int k = 0; k < nm; k++)
            c5.add(C(0, k, 1, 1, L(P(S(m.materi.get(k), false), 0, null, 0, 13, (k + 1) + "."))));
        c5.add(C(0, nm, 1, 1, new ArrayList<Item>()));
        c5.add(C(1, 0, 1, 1, L(T("Dokumentasi", true, "c"))));
        c5.add(C(1, 1, 1, nm, null, null, fotoCustom(m.foto[0])));
        c5.add(C(0, nm + 1, 1, 1, L(T("Masukan Aspek HSSE :", true))));
        for (int k = 0; k < nh; k++) c5.add(C(0, nm + 2 + k, 1, 1, L(T("*" + m.hsse.get(k), false))));
        c5.add(C(0, nm + 2 + nh, 1, 1, L(T("Kendala Aspek HSSE :", true))));
        c5.add(C(0, nm + 3 + nh, 1, 1, linesOf(m.kendala)));
        c5.add(C(1, nm + 1, 1, nh + 3, null, null, fotoCustom(m.foto[1])));
        float[] mh5 = new float[rows];
        for (int z = 0; z < rows; z++) mh5[z] = z == rows - 1 ? 22 : 15;
        cur += table(cur, new float[]{0.62f, 0.38f}, rows, mh5, c5);
        return cur;
    }

    /** Foto mengisi penuh kotak (cover, dipangkas di tengah). */
    Custom fotoCustom(final Model.Img a) {
        return new Custom() {
            public float measure(float w) { return 0; }
            public void draw(float x, float y, float w, float h) {
                if (a == null) return;
                Op o = new Op(); o.k = "img"; o.a = a; o.cover = true;
                o.x = x + 0.5f; o.y = y + 0.5f; o.w = w - 1f; o.h = h - 1f;
                ops.add(o);
            }
        };
    }

    Custom sigCustom(final int k) {
        return new Custom() {
            public float measure(float w) { return 0; }
            public void draw(float x, float y, float w, float h) {
                text(String.valueOf(k + 1), x + 3, y + 2, 6, false, 0.35f);
                Model.Img a = m.denganTtd && k < m.ttd.length ? m.ttd[k] : null;
                if (a != null) {
                    float[] f = fitSize(a.w, a.h, w - 8, h - 13);
                    Op o = new Op(); o.k = "img"; o.a = a; o.x = x + (w - f[0]) / 2; o.y = y + 10 + (h - 13 - f[1]) / 2; o.w = f[0]; o.h = f[1];
                    ops.add(o);
                }
            }
        };
    }

    /** Tata letak dengan skala sehingga selalu muat tepat 1 halaman A4. Koordinat op sudah dalam poin halaman. */
    public static Result fit(Model m, Measurer me) {
        float CW0 = PW - 2 * MX, AVH = PH - 2 * MY;
        float s = 1f;
        Layout l = new Layout(m, me, CW0);
        float H = l.build();
        Layout last = l;
        if (H > AVH) {
            s = AVH / H;
            for (int it = 0; it < 8; it++) {
                last = new Layout(m, me, CW0 / s);
                H = last.build();
                s = Math.max(0.3f, Math.min(1f, AVH / H));
            }
            s *= 0.995f;
        }
        Result r = new Result();
        r.scale = s;
        r.H = H * s;
        for (Op o : last.ops) {
            Op p = new Op();
            p.k = o.k; p.t = o.t; p.b = o.b; p.dash = o.dash; p.cover = o.cover; p.a = o.a; p.col = o.col;
            p.x = MX + o.x * s; p.y = MY + o.y * s; p.w = o.w * s; p.h = o.h * s;
            p.x1 = MX + o.x1 * s; p.y1 = MY + o.y1 * s; p.x2 = MX + o.x2 * s; p.y2 = MY + o.y2 * s;
            p.size = o.size * s;
            r.ops.add(p);
        }
        return r;
    }
}
