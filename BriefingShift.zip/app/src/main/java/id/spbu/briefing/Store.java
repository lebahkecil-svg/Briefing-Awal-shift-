package id.spbu.briefing;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/** Penyimpanan lokal: daftar materi/HSSE permanen (SharedPreferences) dan draft (berkas JSON). */
public class Store {
    final SharedPreferences sp;
    final File draftFile;

    public Store(Context c) {
        sp = c.getSharedPreferences("briefing", Context.MODE_PRIVATE);
        draftFile = new File(c.getFilesDir(), "draft.json");
    }

    public List<String> getList(String key, String[] def) {
        List<String> out = new ArrayList<>();
        String raw = sp.getString(key, null);
        if (raw != null) {
            try {
                JSONArray a = new JSONArray(raw);
                for (int i = 0; i < a.length(); i++) out.add(a.getString(i));
            } catch (JSONException e) { out.clear(); }
        }
        if (out.isEmpty()) for (String s : def) out.add(s);
        return out;
    }

    public void setList(String key, List<String> l) {
        JSONArray a = new JSONArray();
        for (String s : l) a.put(s);
        sp.edit().putString(key, a.toString()).apply();
    }

    public boolean adaDraft() { return draftFile.exists(); }

    public void simpanDraft(String json) throws IOException {
        FileOutputStream o = new FileOutputStream(draftFile);
        try { o.write(json.getBytes("UTF-8")); } finally { o.close(); }
    }

    public String bacaDraft() {
        if (!draftFile.exists()) return null;
        try {
            FileInputStream in = new FileInputStream(draftFile);
            try {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                return bo.toString("UTF-8");
            } finally { in.close(); }
        } catch (IOException e) { return null; }
    }
}
