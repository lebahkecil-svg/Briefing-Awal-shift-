package id.spbu.briefing;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

/** Kanvas tanda tangan digital, tinta biru seperti tanda tangan basah. */
public class SignatureView extends View {
    static final int INK = Color.rgb(20, 50, 190);
    final List<Path> paths = new ArrayList<>();
    Path cur;
    float lx, ly;
    final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint guide = new Paint();

    public SignatureView(Context c) {
        super(c);
        paint.setColor(INK);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setStrokeWidth(5f);
        guide.setColor(Color.rgb(200, 200, 200));
        guide.setStrokeWidth(2f);
        setBackgroundColor(Color.WHITE);
    }

    @Override
    protected void onDraw(Canvas c) {
        float y = getHeight() * 0.72f;
        c.drawLine(getWidth() * 0.05f, y, getWidth() * 0.95f, y, guide);
        for (Path p : paths) c.drawPath(p, paint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        switch (e.getAction()) {
            case MotionEvent.ACTION_DOWN:
                getParent().requestDisallowInterceptTouchEvent(true);
                cur = new Path();
                cur.moveTo(x, y);
                cur.lineTo(x + 0.1f, y + 0.1f);
                paths.add(cur);
                lx = x; ly = y;
                break;
            case MotionEvent.ACTION_MOVE:
                if (cur != null) {
                    cur.quadTo(lx, ly, (x + lx) / 2f, (y + ly) / 2f);
                    lx = x; ly = y;
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (cur != null) cur.lineTo(x, y);
                cur = null;
                break;
        }
        invalidate();
        return true;
    }

    public void clear() { paths.clear(); cur = null; invalidate(); }

    public boolean isEmpty() { return paths.isEmpty(); }

    /** PNG latar transparan, dipangkas ke batas goresan. Hasil: {bytes, lebar, tinggi} lewat Model.Img. */
    public Model.Img export() {
        if (paths.isEmpty()) return null;
        RectF b = new RectF();
        boolean first = true;
        for (Path p : paths) {
            RectF r = new RectF();
            p.computeBounds(r, true);
            if (first) { b.set(r); first = false; } else b.union(r);
        }
        float pad = 8f;
        b.inset(-pad, -pad);
        float w = Math.max(b.width(), 10f), h = Math.max(b.height(), 10f);
        float k = Math.min(1f, 700f / w);
        int bw = Math.max(1, Math.round(w * k)), bh = Math.max(1, Math.round(h * k));
        Bitmap bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        c.scale(k, k);
        c.translate(-b.left, -b.top);
        for (Path p : paths) c.drawPath(p, paint);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.PNG, 100, bo);
        return new Model.Img(bo.toByteArray(), "png", bw, bh);
    }
}
