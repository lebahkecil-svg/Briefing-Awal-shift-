package id.spbu.briefing;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Penulis .docx manual (OOXML), selalu 1 halaman A4 lewat faktor skala f. Tanpa kelas Android. */
public class DocxWriter {
    static final int W = 10200;
    static final int PAGE_H = 16838, MARGIN_TB = 567;
    static final String NS = "xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" "
        + "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" "
        + "xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" "
        + "xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" "
        + "xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\"";

    final Model m;
    final float f;
    final Map<Model.Img, String> rid = new IdentityHashMap<>();
    final List<Model.Img> imgs = new ArrayList<>();
    int imgId = 1;

    DocxWriter(Model m, float f) { this.m = m; this.f = f; }

    static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    int hp(int base) { return Math.max(12, Math.round(base * f)); }
    int tw(int v) { return Math.max(1, Math.round(v * f)); }

    String run(String t, boolean b, boolean u, int size, String color) {
        StringBuilder s = new StringBuilder("<w:r><w:rPr><w:rFonts w:ascii=\"Times New Roman\" w:hAnsi=\"Times New Roman\" w:cs=\"Times New Roman\"/>");
        if (b) s.append("<w:b/>");
        if (u) s.append("<w:u w:val=\"single\"/>");
        if (color != null) s.append("<w:color w:val=\"").append(color).append("\"/>");
        s.append("<w:sz w:val=\"").append(size).append("\"/><w:szCs w:val=\"").append(size).append("\"/></w:rPr>");
        s.append("<w:t xml:space=\"preserve\">").append(esc(t)).append("</w:t></w:r>");
        return s.toString();
    }
    String r(String t) { return run(t, false, false, hp(20), null); }
    String bd(String t) { return run(t, true, false, hp(20), null); }

    String par(String inner, String align, int before, int after, int indentLeft, int hanging, String tabs) {
        StringBuilder s = new StringBuilder("<w:p><w:pPr>");
        if (tabs != null) s.append(tabs);
        s.append("<w:spacing w:before=\"").append(before).append("\" w:after=\"").append(after).append("\"/>");
        if (indentLeft > 0) s.append("<w:ind w:left=\"").append(indentLeft).append("\"").append(hanging > 0 ? " w:hanging=\"" + hanging + "\"" : "").append("/>");
        if (align != null) s.append("<w:jc w:val=\"").append(align).append("\"/>");
        s.append("</w:pPr>").append(inner).append("</w:p>");
        return s.toString();
    }
    String par(String inner) { return par(inner, null, 0, 0, 0, 0, null); }
    String parC(String inner) { return par(inner, "center", 0, 0, 0, 0, null); }

    int[] fit(Model.Img a, int maxW, int maxH) {
        float s = Math.min((float) maxW / a.w, (float) maxH / a.h);
        return new int[]{Math.max(1, Math.round(a.w * s)), Math.max(1, Math.round(a.h * s))};
    }

    String img(Model.Img a, int maxW, int maxH) {
        int[] d = fit(a, Math.max(4, Math.round(maxW * f)), Math.max(4, Math.round(maxH * f)));
        String id = rid.get(a);
        if (id == null) { id = "rIdImg" + imgs.size(); rid.put(a, id); imgs.add(a); }
        long cx = d[0] * 9525L, cy = d[1] * 9525L;
        int n = imgId++;
        return "<w:r><w:drawing><wp:inline distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\"><wp:extent cx=\"" + cx + "\" cy=\"" + cy + "\"/>"
            + "<wp:docPr id=\"" + n + "\" name=\"gambar" + n + "\"/>"
            + "<a:graphic><a:graphicData uri=\"http://schemas.openxmlformats.org/drawingml/2006/picture\"><pic:pic>"
            + "<pic:nvPicPr><pic:cNvPr id=\"" + n + "\" name=\"gambar" + n + "\"/><pic:cNvPicPr/></pic:nvPicPr>"
            + "<pic:blipFill><a:blip r:embed=\"" + id + "\"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>"
            + "<pic:spPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"" + cx + "\" cy=\"" + cy + "\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></pic:spPr>"
            + "</pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>";
    }

    // ---- tabel ----
    static class Cl { int c, r, cs, rs; String xml, va; Cl(int c, int r, int cs, int rs, String xml, String va) { this.c = c; this.r = r; this.cs = cs; this.rs = rs; this.xml = xml; this.va = va; } }

    String tcell(int[] widths, Cl k, int row) {
        int w = 0;
        for (int i = k.c; i < k.c + k.cs; i++) w += widths[i];
        StringBuilder s = new StringBuilder("<w:tc><w:tcPr><w:tcW w:w=\"" + w + "\" w:type=\"dxa\"/>");
        if (k.cs > 1) s.append("<w:gridSpan w:val=\"").append(k.cs).append("\"/>");
        if (k.rs > 1) s.append(row == k.r ? "<w:vMerge w:val=\"restart\"/>" : "<w:vMerge/>");
        int mv = Math.max(8, Math.round(25 * f)), mh = Math.max(30, Math.round(80 * f));
        s.append("<w:tcMar><w:top w:w=\"" + mv + "\" w:type=\"dxa\"/><w:left w:w=\"" + mh + "\" w:type=\"dxa\"/><w:bottom w:w=\"" + mv + "\" w:type=\"dxa\"/><w:right w:w=\"" + mh + "\" w:type=\"dxa\"/></w:tcMar>");
        if (k.va != null) s.append("<w:vAlign w:val=\"").append(k.va).append("\"/>");
        s.append("</w:tcPr>");
        if (row == k.r) s.append(k.xml == null || k.xml.isEmpty() ? par(r("")) : k.xml); else s.append(par(""));
        s.append("</w:tc>");
        return s.toString();
    }

    String table(int[] widths, int nrows, int[] heights, List<Cl> cells) {
        int total = 0;
        for (int x : widths) total += x;
        StringBuilder s = new StringBuilder("<w:tbl><w:tblPr><w:tblW w:w=\"" + total + "\" w:type=\"dxa\"/><w:tblLayout w:type=\"fixed\"/><w:tblBorders>");
        for (String e : new String[]{"top", "left", "bottom", "right", "insideH", "insideV"})
            s.append("<w:").append(e).append(" w:val=\"single\" w:sz=\"4\" w:space=\"0\" w:color=\"333333\"/>");
        s.append("</w:tblBorders></w:tblPr><w:tblGrid>");
        for (int x : widths) s.append("<w:gridCol w:w=\"").append(x).append("\"/>");
        s.append("</w:tblGrid>");
        for (int row = 0; row < nrows; row++) {
            s.append("<w:tr><w:trPr><w:cantSplit/>");
            int h = heights != null && row < heights.length ? heights[row] : 0;
            if (h > 0) s.append("<w:trHeight w:val=\"").append(h).append("\" w:hRule=\"atLeast\"/>");
            s.append("</w:trPr>");
            int c = 0;
            while (c < widths.length) {
                Cl hit = null;
                for (Cl k : cells) if (k.c == c && k.r <= row && row < k.r + k.rs) { hit = k; break; }
                if (hit == null) { c++; continue; }
                s.append(tcell(widths, hit, row));
                c += hit.cs;
            }
            s.append("</w:tr>");
        }
        s.append("</w:tbl>");
        return s.toString();
    }

    String gap() { return "<w:p><w:pPr><w:spacing w:before=\"0\" w:after=\"0\" w:line=\"20\" w:lineRule=\"exact\"/></w:pPr></w:p>"; }

    String lines(String t) {
        StringBuilder s = new StringBuilder();
        for (String x : (t == null ? "" : t).split("\n", -1)) s.append(par(r(x)));
        return s.toString();
    }

    String body(int[] hOut) {
        StringBuilder b = new StringBuilder();
        b.append(par(run("SHIFT " + m.no, true, false, hp(24), null), null, 0, tw(120), 0, 0, null));

        // Tabel 1
        int c1 = Math.round(W * 0.33f), c2 = Math.round(W * 0.30f), c3 = W - c1 - c2;
        int[] w1 = {c1, c2, c3};
        String tab = "<w:tabs><w:tab w:val=\"right\" w:pos=\"" + (c1 + c2 - 200) + "\"/></w:tabs>";
        String judul = par(bd("BRIEFING PERGANTIAN SHIFT") + run("\t", false, false, hp(20), null) + (m.logo != null ? img(m.logo, 150, 40) : ""), null, 0, 0, 0, 0, tab);
        String disetujui = par(bd("Disetujui :"))
            + (m.logoDisetujui && m.logo != null ? par(img(m.logo, 120, 34), "center", tw(120), 0, 0, 0, null) : par(r(""), null, tw(400), 0, 0, 0, null))
            + par(run("FERLIQ PONTUMIKA YUDITAMA", true, true, hp(20), null), "center", tw(200), 0, 0, 0, null)
            + par(bd("BUH SPBU"), "center", 0, 0, 0, 0, null);
        List<Cl> t1 = new ArrayList<>();
        t1.add(new Cl(0, 0, 2, 2, judul, "center"));
        t1.add(new Cl(2, 0, 1, 1, par(bd("No. Dokumen : " + m.nomorDok)), null));
        t1.add(new Cl(2, 1, 1, 1, par(bd("Revisi :")), null));
        t1.add(new Cl(0, 2, 1, 2, par(bd("Tanggal : ") + r(m.tgl)) + par(r("")) + par(bd("Shift : ") + r(m.no)), null));
        t1.add(new Cl(1, 2, 1, 1, par(bd("Dipimpin : ") + r(m.dipimpin)), null));
        t1.add(new Cl(2, 2, 1, 3, disetujui, null));
        t1.add(new Cl(1, 3, 1, 1, par(bd("KA. SHIFT : ") + r(m.kashift)), null));
        t1.add(new Cl(0, 4, 1, 1, par(bd("No SPBU: 31-10702")) + par(bd("Lokasi SPBU: Jl. Samanhudi")) + par(bd("COCO SAMANHUDI"), null, 0, 0, tw(400), 0, null), null));
        t1.add(new Cl(1, 4, 1, 1, par(bd("DICATAT : ") + r(m.dicatat)), null));
        b.append(table(w1, 5, null, t1)).append(gap());

        // Tabel 2
        List<Cl> t2 = new ArrayList<>();
        t2.add(new Cl(0, 0, 1, 1, par(bd("Topik Bahasan :")), null));
        t2.add(new Cl(0, 1, 1, 1, lines(m.topik), null));
        b.append(table(new int[]{W}, 2, new int[]{0, tw(700)}, t2)).append(gap());

        // Tabel 3
        int[] pw = new int[5];
        float[] fr = {0.07f, 0.30f, 0.19f, 0.22f, 0.22f};
        int sum = 0;
        for (int i = 0; i < 4; i++) { pw[i] = Math.round(W * fr[i]); sum += pw[i]; }
        pw[4] = W - sum;
        int n = m.jumlahBaris();
        List<Cl> t3 = new ArrayList<>();
        t3.add(new Cl(0, 0, 2, 1, par(bd("Peserta :")), null));
        t3.add(new Cl(2, 0, 1, 1, parC(bd("Jabatan")), null));
        t3.add(new Cl(3, 0, 2, 1, parC(bd("Tanda Tangan")), null));
        for (int i = 0; i < n; i++) {
            String[] p = i < m.peserta.size() ? m.peserta.get(i) : null;
            t3.add(new Cl(0, i + 1, 1, 1, parC(bd(String.valueOf(i + 1))), "center"));
            t3.add(new Cl(1, i + 1, 1, 1, par(r(p != null ? p[0] : "")), "center"));
            t3.add(new Cl(2, i + 1, 1, 1, par(r(p != null ? p[1] : "")), "center"));
            if (i % 2 == 0) {
                if (i + 1 < n) {
                    t3.add(new Cl(3, i + 1, 1, 2, sig(i, 2), null));
                    t3.add(new Cl(4, i + 1, 1, 2, sig(i + 1, 2), null));
                } else {
                    t3.add(new Cl(3, i + 1, 2, 1, sig(i, 1), null)); // ganjil: kolom tanda tangan digabung
                }
            }
        }
        int[] h3 = new int[n + 1];
        for (int i = 1; i <= n; i++) h3[i] = tw(520);
        if (n % 2 == 1) h3[n] = tw(780); // 1,5 x tinggi normal
        b.append(table(pw, n + 1, h3, t3)).append(gap());

        // Tabel 4
        List<Cl> t4 = new ArrayList<>();
        t4.add(new Cl(0, 0, 1, 1, par(bd("Ringkasan Materi Briefing :")), null));
        b.append(table(new int[]{W}, 1, null, t4)).append(gap());

        // Tabel 5
        int lw = Math.round(W * 0.62f), rw = W - lw;
        int nm = m.materi.size(), nh = m.hsse.size();
        int rows = nm + 1 + nh + 3;
        List<Cl> t5 = new ArrayList<>();
        for (int k = 0; k < nm; k++)
            t5.add(new Cl(0, k, 1, 1, par(r((k + 1) + ".  ") + r(m.materi.get(k)), null, 0, 0, tw(400), tw(400), null), null));
        t5.add(new Cl(0, nm, 1, 1, "", null));
        t5.add(new Cl(1, 0, 1, 1, parC(bd("Dokumentasi")), null));
        StringBuilder fp = new StringBuilder();
        for (Model.Img a : m.foto) if (a != null) fp.append(par(img(a, 200, 118), "center", tw(40), tw(40), 0, 0, null));
        if (fp.length() == 0) fp.append(par(r("")));
        t5.add(new Cl(1, 1, 1, nm, fp.toString(), null));
        t5.add(new Cl(0, nm + 1, 1, 1, par(bd("Masukan Aspek HSSE:")), null));
        for (int k = 0; k < nh; k++) t5.add(new Cl(0, nm + 2 + k, 1, 1, par(r("*" + m.hsse.get(k))), null));
        t5.add(new Cl(0, nm + 2 + nh, 1, 1, par(bd("Kendala Aspek HSSE :")), null));
        t5.add(new Cl(0, nm + 3 + nh, 1, 1, lines(m.kendala), null));
        t5.add(new Cl(1, nm + 1, 1, nh + 3, "", null));
        int[] h5 = new int[rows];
        h5[rows - 1] = tw(500);
        b.append(table(new int[]{lw, rw}, rows, h5, t5));
        return b.toString();
    }

    String sig(int k, int span) {
        String s = par(run(String.valueOf(k + 1), false, false, 12, "555555"));
        Model.Img a = m.denganTtd && k < m.ttd.length ? m.ttd[k] : null;
        if (a != null) s += par(span == 2 ? img(a, 130, 52) : img(a, 260, 50), "center", 0, 0, 0, 0, null);
        return s;
    }

    /** Perkiraan tinggi isi (twip) pada skala f, dipakai memilih f agar muat satu halaman. */
    static float perkiraanTinggi(Model m, float f) {
        float fs = 10 * f;                // pt
        float lh = fs * 1.15f * 20;       // tinggi baris (twip)
        float pad = 2 * Math.max(8, 25 * f) + 10;
        float cw = fs * 0.47f * 20;       // lebar rata2 huruf (twip)
        float t = 0;
        t += 12 * f * 1.15f * 20 + 120 * f;                        // judul SHIFT
        float disetujui = lh * 3 + (m.logoDisetujui && m.logo != null ? 34 * 15 * f + 120 * f : 400 * f + lh) + 200 * f + pad;
        float r01 = Math.max(2 * (lh + pad), (m.logo != null ? 40 * 15 * f : 0) + pad);
        t += r01 + Math.max(2 * (3 * lh + pad), disetujui) + 20;
        t += 2 * (lh + pad) ;
        int tl = 1; for (char c : (m.topik == null ? "" : m.topik).toCharArray()) if (c == '\n') tl++;
        t += lh + pad + Math.max(700 * f, tl * lh + pad) + 20;
        int n = m.jumlahBaris();
        t += lh + pad + n * Math.max(520 * f, lh + pad) + (n % 2 == 1 ? 260 * f : 0) + 20;
        t += lh + pad + 20;
        float lw = W * 0.62f - 160 * f - 400 * f;
        float mat = 0;
        for (int k = 0; k < m.materi.size(); k++) {
            int lines = (int) Math.ceil(m.materi.get(k).length() * cw / lw);
            mat += Math.max(1, lines) * lh + pad;
        }
        mat += lh + pad;                                           // baris kosong
        float foto = 0;
        for (Model.Img a : m.foto) if (a != null) {
            float s = Math.min(200f / a.w, 118f / a.h);
            foto += a.h * s * 15 * f + 80 * f + 30;
        }
        t += Math.max(mat, foto + lh + pad);
        t += lh + pad;                                             // header HSSE
        for (String x : m.hsse) t += Math.max(1, (int) Math.ceil((x.length() + 1) * cw / lw)) * lh + pad;
        t += lh + pad + Math.max(500 * f, lh + pad);
        return t;
    }

    public static float pilihSkala(Model m) {
        float avail = PAGE_H - 2 * MARGIN_TB;
        float f = 1f;
        for (int i = 0; i < 6; i++) {
            float h = perkiraanTinggi(m, f);
            if (h <= avail * 0.94f && i > 0) break;
            f = Math.max(0.35f, Math.min(1f, f * avail * 0.94f / h));
        }
        return f;
    }

    public static byte[] build(Model m) throws java.io.IOException {
        float f = pilihSkala(m);
        DocxWriter d = new DocxWriter(m, f);
        String body = d.body(null);
        String doc = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><w:document " + NS + "><w:body>" + body
            + "<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/><w:pgMar w:top=\"" + MARGIN_TB + "\" w:right=\"850\" w:bottom=\"" + MARGIN_TB + "\" w:left=\"850\" w:header=\"0\" w:footer=\"0\" w:gutter=\"0\"/></w:sectPr></w:body></w:document>";
        StringBuilder rels = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");
        for (int i = 0; i < d.imgs.size(); i++) {
            Model.Img a = d.imgs.get(i);
            rels.append("<Relationship Id=\"rIdImg").append(i).append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"media/img")
                .append(i).append(a.type.equals("png") ? ".png" : ".jpg").append("\"/>");
        }
        rels.append("</Relationships>");
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        ZipOutputStream z = new ZipOutputStream(bo);
        put(z, "[Content_Types].xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
            + "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/>"
            + "<Default Extension=\"png\" ContentType=\"image/png\"/><Default Extension=\"jpg\" ContentType=\"image/jpeg\"/>"
            + "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/></Types>");
        put(z, "_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
            + "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/></Relationships>");
        put(z, "word/document.xml", doc);
        put(z, "word/_rels/document.xml.rels", rels.toString());
        for (int i = 0; i < d.imgs.size(); i++) {
            Model.Img a = d.imgs.get(i);
            z.putNextEntry(new ZipEntry("word/media/img" + i + (a.type.equals("png") ? ".png" : ".jpg")));
            z.write(a.bytes);
            z.closeEntry();
        }
        z.close();
        return bo.toByteArray();
    }

    static void put(ZipOutputStream z, String name, String s) throws java.io.IOException {
        z.putNextEntry(new ZipEntry(name));
        z.write(s.getBytes("UTF-8"));
        z.closeEntry();
    }
}
