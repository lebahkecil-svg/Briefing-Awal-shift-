package id.spbu.briefing;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Typeface;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.text.InputType;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    static final int REQ_FOTO = 100, REQ_SAVE = 200;
    static final int BLUE = Color.rgb(11, 92, 173);

    Store store;
    boolean adminOk = false;
    List<String> materi, hsse;

    // form
    Spinner spTanggal, spShift;
    NameSpinner spDipimpin, spDicatat, spKa;
    final List<String> tglIso = new ArrayList<>();
    EditText etTopik, etKendala;
    CheckBox cbLogo;
    TextView tvNoDok, tvDraft, tvMateri, tvHsse;
    Button btnUbahMateri, btnUbahHsse, btnUbahForm;
    LinearLayout pesertaBox;
    final List<PRow> rows = new ArrayList<>();
    final byte[][] fotoBytes = new byte[2][];
    final ImageView[] fotoView = new ImageView[2];
    View formRoot;

    // output
    boolean denganTtd = true;
    String pendingFmt;
    ImageView previewIv;
    boolean zoomed = false;
    Layout.Result lastResult;

    static class PRow {
        LinearLayout box;
        NameSpinner sp;
        TextView jab, no;
        ImageView thumb;
        Button btnTtd;
        Model.Img ttd;
    }

    // ---------- util ----------
    int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    TextView tv(String t, int sp, boolean bold, int color) {
        TextView x = new TextView(this);
        x.setText(t);
        x.setTextSize(sp);
        x.setTextColor(color);
        if (bold) x.setTypeface(Typeface.DEFAULT_BOLD);
        return x;
    }

    LinearLayout.LayoutParams lp(int w, int h, int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.topMargin = dp(top);
        return p;
    }

    TextView section(String t) {
        TextView x = tv(t, 17, true, BLUE);
        x.setPadding(0, dp(18), 0, dp(4));
        return x;
    }

    TextView label(String t) {
        TextView x = tv(t, 13, true, Color.rgb(70, 70, 70));
        x.setPadding(0, dp(10), 0, dp(2));
        return x;
    }

    Button btn(String t, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    // ---------- Spinner nama ----------
    class NameSpinner extends Spinner {
        final List<String> items = new ArrayList<>();
        int lastPos = 0;
        boolean silent = false;
        Runnable onChange;

        NameSpinner(Context c, boolean semua) {
            super(c);
            items.add("Pilih nama");
            if (semua) items.addAll(Data.semuaNama());
            else for (String k : Data.KA_SHIFT) items.add(k);
            ArrayAdapter<String> ad = new ArrayAdapter<String>(c, android.R.layout.simple_spinner_item, items) {
                @Override public boolean isEnabled(int pos) { return !items.get(pos).startsWith("§"); }
                @Override public View getView(int pos, View cv, ViewGroup parent) {
                    TextView t = (TextView) super.getView(pos, cv, parent);
                    t.setText(clean(items.get(pos)));
                    return t;
                }
                @Override public View getDropDownView(int pos, View cv, ViewGroup parent) {
                    TextView t = (TextView) super.getDropDownView(pos, cv, parent);
                    String s = items.get(pos);
                    t.setPadding(dp(14), dp(10), dp(14), dp(10));
                    if (s.startsWith("§")) {
                        t.setText(s.substring(1));
                        t.setTypeface(Typeface.DEFAULT_BOLD);
                        t.setTextColor(BLUE);
                        t.setBackgroundColor(Color.rgb(232, 240, 250));
                    } else {
                        t.setText(s);
                        t.setTypeface(Typeface.DEFAULT);
                        t.setTextColor(Color.BLACK);
                        t.setBackgroundColor(Color.WHITE);
                    }
                    return t;
                }
            };
            ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            setAdapter(ad);
            setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                    if (silent) return;
                    final String nm = value();
                    if (nm.equals(Data.ADMIN_NAME) && !adminOk) {
                        final int prev = lastPos;
                        askPassword(new Runnable() {
                            public void run() { lastPos = getSelectedItemPosition(); fire(); }
                        }, new Runnable() {
                            public void run() { silent = true; setSelection(prev); silent = false; }
                        });
                        return;
                    }
                    lastPos = pos;
                    fire();
                }
                @Override public void onNothingSelected(AdapterView<?> p) { }
            });
        }

        String clean(String s) { return s.startsWith("§") ? s.substring(1) : s; }

        void fire() { if (onChange != null) onChange.run(); }

        String value() {
            int p = getSelectedItemPosition();
            if (p <= 0 || p >= items.size()) return "";
            String s = items.get(p);
            return s.startsWith("§") ? "" : s;
        }

        void setValue(String v) {
            int idx = 0;
            for (int i = 1; i < items.size(); i++) if (items.get(i).equals(v)) { idx = i; break; }
            silent = true;
            setSelection(idx);
            silent = false;
            lastPos = idx;
        }
    }

    // ---------- password ----------
    void askPassword(final Runnable ok, final Runnable cancel) {
        final EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        et.setHint("Password");
        final boolean[] done = {false};
        final AlertDialog d = new AlertDialog.Builder(this)
            .setTitle("Password")
            .setView(et)
            .setPositiveButton("OK", null)
            .setNegativeButton("Batal", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface di, int w) { }
            })
            .create();
        d.setOnDismissListener(new DialogInterface.OnDismissListener() {
            public void onDismiss(DialogInterface di) { if (!done[0] && cancel != null) cancel.run(); }
        });
        d.show();
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (et.getText().toString().equals(Data.ADMIN_PW)) {
                    adminOk = true;
                    done[0] = true;
                    d.dismiss();
                    updateAdminUi();
                    if (ok != null) ok.run();
                } else {
                    et.setError("Password salah");
                }
            }
        });
    }

    void updateAdminUi() {
        int vis = adminOk ? View.VISIBLE : View.GONE;
        btnUbahMateri.setVisibility(vis);
        btnUbahHsse.setVisibility(vis);
        btnUbahForm.setText(adminOk ? "Mode ubah aktif" : "Ubah form");
    }

    // ---------- siklus hidup ----------
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        store = new Store(this);
        materi = store.getList("materi", Data.MATERI_DEFAULT);
        hsse = store.getList("hsse", Data.HSSE_DEFAULT);
        buildForm();
        setContentView(formRoot);
        updateAdminUi();
        updateNoDok();
        updateDraftInfo();
    }

    @Override public void onBackPressed() {
        if (formRoot != null && formRoot.getParent() == null) {
            setContentView(formRoot);
        } else super.onBackPressed();
    }

    // ---------- form ----------
    void buildForm() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.WHITE);
        sv.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(20), dp(16), dp(32));
        sv.addView(root, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        formRoot = sv;

        root.addView(tv("Briefing Pergantian Shift", 22, true, Color.BLACK));
        root.addView(tv("SPBU COCO 31.107.02 Samanhudi", 13, false, Color.GRAY));
        tvNoDok = tv("", 14, true, BLUE);
        tvNoDok.setPadding(0, dp(8), 0, 0);
        root.addView(tvNoDok);
        btnUbahForm = btn("Ubah form", new View.OnClickListener() {
            public void onClick(View v) { if (!adminOk) askPassword(null, null); }
        });
        root.addView(btnUbahForm);

        // Data briefing
        root.addView(section("Data briefing"));
        root.addView(label("Tanggal"));
        spTanggal = new Spinner(this);
        Calendar cal = Calendar.getInstance();
        List<String> labels = new ArrayList<>();
        SimpleDateFormat iso = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        int today = 0;
        for (int i = -7; i <= 2; i++) {
            Calendar c = (Calendar) cal.clone();
            c.add(Calendar.DAY_OF_MONTH, i);
            tglIso.add(iso.format(c.getTime()));
            labels.add(Data.HARI[c.get(Calendar.DAY_OF_WEEK) - 1] + ", " + c.get(Calendar.DAY_OF_MONTH) + " " + Data.BULAN[c.get(Calendar.MONTH)] + " " + c.get(Calendar.YEAR));
            if (i == 0) today = labels.size() - 1;
        }
        spTanggal.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, labels));
        spTanggal.setSelection(today);
        root.addView(spTanggal);

        root.addView(label("Shift"));
        spShift = new Spinner(this);
        List<String> shifts = new ArrayList<>();
        shifts.add("Pilih shift");
        for (String s : Data.SHIFT) shifts.add(s);
        spShift.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, shifts));
        root.addView(spShift);
        AdapterView.OnItemSelectedListener noDokL = new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) { updateNoDok(); }
            public void onNothingSelected(AdapterView<?> p) { }
        };
        spTanggal.setOnItemSelectedListener(noDokL);
        spShift.setOnItemSelectedListener(noDokL);

        root.addView(label("Dipimpin"));
        spDipimpin = new NameSpinner(this, true);
        root.addView(spDipimpin);
        root.addView(label("Dicatat"));
        spDicatat = new NameSpinner(this, true);
        root.addView(spDicatat);
        root.addView(label("Ka. Shift"));
        spKa = new NameSpinner(this, false);
        root.addView(spKa);

        root.addView(label("Topik bahasan"));
        etTopik = new EditText(this);
        etTopik.setMinLines(3);
        etTopik.setGravity(Gravity.TOP);
        etTopik.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        root.addView(etTopik);

        cbLogo = new CheckBox(this);
        cbLogo.setText("Logo di kotak Disetujui : Off");
        cbLogo.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(android.widget.CompoundButton b, boolean on) {
                b.setText("Logo di kotak Disetujui : " + (on ? "On" : "Off"));
            }
        });
        root.addView(cbLogo, lp(-2, -2, 10));

        // Peserta
        root.addView(section("Peserta briefing"));
        pesertaBox = new LinearLayout(this);
        pesertaBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(pesertaBox);
        addRow();
        root.addView(btn("+ Tambah peserta", new View.OnClickListener() {
            public void onClick(View v) { addRow(); }
        }));

        // Ringkasan
        root.addView(section("Ringkasan materi briefing"));
        tvMateri = tv("", 14, false, Color.BLACK);
        root.addView(tvMateri);
        btnUbahMateri = btn("Ubah ringkasan materi (permanen)", new View.OnClickListener() {
            public void onClick(View v) { editList("materi"); }
        });
        root.addView(btnUbahMateri);
        root.addView(section("Masukan aspek HSSE"));
        tvHsse = tv("", 14, false, Color.BLACK);
        root.addView(tvHsse);
        btnUbahHsse = btn("Ubah masukan HSSE (permanen)", new View.OnClickListener() {
            public void onClick(View v) { editList("hsse"); }
        });
        root.addView(btnUbahHsse);
        root.addView(label("Kendala aspek HSSE"));
        etKendala = new EditText(this);
        etKendala.setMinLines(2);
        etKendala.setGravity(Gravity.TOP);
        etKendala.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        root.addView(etKendala);
        renderLists();

        // Dokumentasi
        root.addView(section("Dokumentasi (2 foto dari galeri)"));
        for (int i = 0; i < 2; i++) {
            final int slot = i;
            LinearLayout r = new LinearLayout(this);
            r.setOrientation(LinearLayout.HORIZONTAL);
            r.setGravity(Gravity.CENTER_VERTICAL);
            fotoView[i] = new ImageView(this);
            fotoView[i].setBackgroundColor(Color.rgb(238, 238, 238));
            fotoView[i].setScaleType(ImageView.ScaleType.CENTER_CROP);
            r.addView(fotoView[i], new LinearLayout.LayoutParams(dp(96), dp(72)));
            Button pilih = btn("Foto " + (i + 1) + ": Pilih", new View.OnClickListener() {
                public void onClick(View v) {
                    Intent it = new Intent(Intent.ACTION_GET_CONTENT);
                    it.setType("image/*");
                    startActivityForResult(Intent.createChooser(it, "Pilih foto"), REQ_FOTO + slot);
                }
            });
            r.addView(pilih);
            r.addView(btn("Hapus", new View.OnClickListener() {
                public void onClick(View v) { fotoBytes[slot] = null; fotoView[slot].setImageBitmap(null); }
            }));
            root.addView(r, lp(-1, -2, 6));
        }

        // Draft
        root.addView(section("Draft"));
        tvDraft = tv("", 13, false, Color.GRAY);
        root.addView(tvDraft);
        LinearLayout dr = new LinearLayout(this);
        dr.addView(btn("Simpan draft", new View.OnClickListener() {
            public void onClick(View v) { simpanDraft(); }
        }), new LinearLayout.LayoutParams(0, -2, 1));
        dr.addView(btn("Muat draft", new View.OnClickListener() {
            public void onClick(View v) { muatDraft(); }
        }), new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(dr);

        Button hasil = btn("Lihat hasil & cetak / simpan", new View.OnClickListener() {
            public void onClick(View v) { lihatHasil(); }
        });
        hasil.setTextSize(16);
        root.addView(hasil, lp(-1, -2, 20));
    }

    void updateNoDok() {
        if (spTanggal == null || spShift == null || tvNoDok == null) return;
        int p = spTanggal.getSelectedItemPosition();
        if (p < 0 || p >= tglIso.size()) return;
        String sh = spShift.getSelectedItemPosition() > 0 ? Data.SHIFT[spShift.getSelectedItemPosition() - 1] : "";
        tvNoDok.setText("No. Dokumen : " + Data.nomorDokumen(tglIso.get(p), sh));
    }

    void renderLists() {
        StringBuilder a = new StringBuilder();
        for (int i = 0; i < materi.size(); i++) a.append(i + 1).append(". ").append(materi.get(i).trim()).append('\n');
        tvMateri.setText(a.toString().trim());
        StringBuilder b = new StringBuilder();
        for (String s : hsse) b.append("* ").append(s.trim()).append('\n');
        tvHsse.setText(b.toString().trim());
    }

    void editList(final String key) {
        final List<String> src = key.equals("materi") ? materi : hsse;
        final EditText et = new EditText(this);
        et.setMinLines(8);
        et.setGravity(Gravity.TOP);
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        StringBuilder sb = new StringBuilder();
        for (String s : src) sb.append(s.trim()).append('\n');
        et.setText(sb.toString().trim());
        new AlertDialog.Builder(this)
            .setTitle("Satu butir per baris")
            .setView(et)
            .setNegativeButton("Batal", null)
            .setPositiveButton("Simpan permanen", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    List<String> n = new ArrayList<>();
                    for (String line : et.getText().toString().split("\n")) if (!line.trim().isEmpty()) n.add(line.trim());
                    if (n.isEmpty()) { toast("Daftar tidak boleh kosong"); return; }
                    if (key.equals("materi")) materi = n; else hsse = n;
                    store.setList(key, n);
                    renderLists();
                    toast("Tersimpan");
                }
            }).show();
    }

    // ---------- baris peserta ----------
    void addRow() {
        final PRow r = new PRow();
        final int idx = rows.size();
        r.box = new LinearLayout(this);
        r.box.setOrientation(LinearLayout.VERTICAL);
        r.box.setPadding(dp(10), dp(8), dp(10), dp(8));
        r.box.setBackgroundColor(idx % 2 == 0 ? Color.rgb(246, 248, 251) : Color.WHITE);
        LinearLayout l1 = new LinearLayout(this);
        l1.setGravity(Gravity.CENTER_VERTICAL);
        r.no = tv((idx + 1) + ".", 15, true, Color.BLACK);
        l1.addView(r.no, new LinearLayout.LayoutParams(dp(30), -2));
        r.sp = new NameSpinner(this, true);
        l1.addView(r.sp, new LinearLayout.LayoutParams(0, -2, 1));
        r.box.addView(l1);
        LinearLayout l2 = new LinearLayout(this);
        l2.setGravity(Gravity.CENTER_VERTICAL);
        r.jab = tv("", 13, false, Color.DKGRAY);
        l2.addView(r.jab, new LinearLayout.LayoutParams(0, -2, 1));
        r.thumb = new ImageView(this);
        r.thumb.setScaleType(ImageView.ScaleType.FIT_CENTER);
        l2.addView(r.thumb, new LinearLayout.LayoutParams(dp(90), dp(44)));
        r.btnTtd = btn("Tanda tangan", new View.OnClickListener() {
            public void onClick(View v) { tandaTangan(r); }
        });
        l2.addView(r.btnTtd);
        l2.addView(btn("Hapus", new View.OnClickListener() {
            public void onClick(View v) { hapusRow(r); }
        }));
        r.box.addView(l2);
        r.sp.onChange = new Runnable() {
            public void run() { r.jab.setText(Data.jabatanDari(r.sp.value()).isEmpty() ? "" : "Jabatan: " + Data.jabatanDari(r.sp.value())); }
        };
        rows.add(r);
        pesertaBox.addView(r.box);
    }

    void hapusRow(PRow r) {
        if (rows.size() <= 1) {
            r.sp.setValue("");
            r.sp.fire();
            setTtd(r, null);
            return;
        }
        rows.remove(r);
        pesertaBox.removeView(r.box);
        for (int i = 0; i < rows.size(); i++) {
            rows.get(i).no.setText((i + 1) + ".");
            rows.get(i).box.setBackgroundColor(i % 2 == 0 ? Color.rgb(246, 248, 251) : Color.WHITE);
        }
    }

    void tandaTangan(final PRow r) {
        final SignatureView sig = new SignatureView(this);
        FrameLayout fl = new FrameLayout(this);
        fl.setPadding(dp(8), dp(8), dp(8), dp(8));
        fl.addView(sig, new FrameLayout.LayoutParams(-1, dp(260)));
        final AlertDialog d = new AlertDialog.Builder(this)
            .setTitle("Tanda tangan: " + (r.sp.value().isEmpty() ? "peserta" : r.sp.value()))
            .setView(fl)
            .setNegativeButton("Batal", null)
            .setNeutralButton("Hapus", null)
            .setPositiveButton("Simpan", null)
            .create();
        d.show();
        d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { sig.clear(); r.ttd = null; r.thumb.setImageBitmap(null); }
        });
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Model.Img im = sig.export();
                if (im == null) { toast("Tanda tangan masih kosong"); return; }
                setTtd(r, im);
                d.dismiss();
            }
        });
    }

    void setTtd(PRow r, Model.Img im) {
        r.ttd = im;
        if (im == null) { r.thumb.setImageBitmap(null); return; }
        r.thumb.setImageBitmap(BitmapFactory.decodeByteArray(im.bytes, 0, im.bytes.length));
    }

    // ---------- foto ----------
    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri u = data.getData();
        if (req == REQ_FOTO || req == REQ_FOTO + 1) {
            int slot = req - REQ_FOTO;
            try {
                byte[] jpg = bacaFoto(u);
                fotoBytes[slot] = jpg;
                fotoView[slot].setImageBitmap(BitmapFactory.decodeByteArray(jpg, 0, jpg.length));
            } catch (Exception e) { toast("Foto gagal dibaca"); }
        } else if (req == REQ_SAVE) {
            try {
                byte[] out = buatFile(pendingFmt);
                OutputStream os = getContentResolver().openOutputStream(u);
                os.write(out);
                os.close();
                toast("Tersimpan");
            } catch (Exception e) { toast("Gagal menyimpan: " + e.getMessage()); }
        }
    }

    byte[] bacaFoto(Uri u) throws Exception {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        InputStream in = getContentResolver().openInputStream(u);
        BitmapFactory.decodeStream(in, null, o);
        in.close();
        int s = 1;
        while (Math.max(o.outWidth, o.outHeight) / s > 1400) s *= 2;
        o = new BitmapFactory.Options();
        o.inSampleSize = s;
        in = getContentResolver().openInputStream(u);
        Bitmap bm = BitmapFactory.decodeStream(in, null, o);
        in.close();
        int rot = 0;
        try {
            in = getContentResolver().openInputStream(u);
            int ori = new ExifInterface(in).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1);
            in.close();
            if (ori == 6) rot = 90; else if (ori == 3) rot = 180; else if (ori == 8) rot = 270;
        } catch (Exception e) { rot = 0; }
        if (rot != 0) {
            Matrix mx = new Matrix();
            mx.postRotate(rot);
            bm = Bitmap.createBitmap(bm, 0, 0, bm.getWidth(), bm.getHeight(), mx, true);
        }
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.JPEG, 85, bo);
        return bo.toByteArray();
    }

    // ---------- draft ----------
    void updateDraftInfo() {
        tvDraft.setText(store.adaDraft() ? "Draft tersimpan di perangkat ini." : "Belum ada draft.");
    }

    String b64(byte[] b) { return b == null ? "" : Base64.encodeToString(b, Base64.NO_WRAP); }

    void simpanDraft() {
        try {
            JSONObject d = new JSONObject();
            d.put("tanggal", tglIso.get(spTanggal.getSelectedItemPosition()));
            d.put("shift", spShift.getSelectedItemPosition());
            d.put("dipimpin", spDipimpin.value());
            d.put("dicatat", spDicatat.value());
            d.put("kashift", spKa.value());
            d.put("topik", etTopik.getText().toString());
            d.put("kendala", etKendala.getText().toString());
            d.put("logo", cbLogo.isChecked());
            d.put("waktu", new SimpleDateFormat("d MMM HH:mm", new Locale("id", "ID")).format(new Date()));
            JSONArray pa = new JSONArray();
            for (PRow r : rows) {
                JSONObject p = new JSONObject();
                p.put("nama", r.sp.value());
                p.put("ttd", r.ttd == null ? "" : b64(r.ttd.bytes));
                p.put("w", r.ttd == null ? 0 : r.ttd.w);
                p.put("h", r.ttd == null ? 0 : r.ttd.h);
                pa.put(p);
            }
            d.put("peserta", pa);
            JSONArray fa = new JSONArray();
            for (int i = 0; i < 2; i++) fa.put(b64(fotoBytes[i]));
            d.put("foto", fa);
            store.simpanDraft(d.toString());
            tvDraft.setText("Draft tersimpan " + d.getString("waktu") + ".");
            toast("Draft tersimpan");
        } catch (Exception e) { toast("Draft gagal disimpan"); }
    }

    void muatDraft() {
        String raw = store.bacaDraft();
        if (raw == null) { toast("Belum ada draft"); return; }
        try {
            JSONObject d = new JSONObject(raw);
            String tg = d.optString("tanggal");
            int idx = tglIso.indexOf(tg);
            if (idx < 0 && !tg.isEmpty()) {
                tglIso.add(0, tg);
                List<String> labels = new ArrayList<>();
                for (String iso : tglIso) {
                    String[] t = iso.split("-");
                    Calendar c = Calendar.getInstance();
                    c.set(Integer.parseInt(t[0]), Integer.parseInt(t[1]) - 1, Integer.parseInt(t[2]));
                    labels.add(Data.HARI[c.get(Calendar.DAY_OF_WEEK) - 1] + ", " + c.get(Calendar.DAY_OF_MONTH) + " " + Data.BULAN[c.get(Calendar.MONTH)] + " " + c.get(Calendar.YEAR));
                }
                spTanggal.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, labels));
                idx = 0;
            }
            if (idx >= 0) spTanggal.setSelection(idx);
            spShift.setSelection(d.optInt("shift"));
            spDipimpin.setValue(d.optString("dipimpin"));
            spDicatat.setValue(d.optString("dicatat"));
            spKa.setValue(d.optString("kashift"));
            etTopik.setText(d.optString("topik"));
            etKendala.setText(d.optString("kendala"));
            cbLogo.setChecked(d.optBoolean("logo"));
            JSONArray pa = d.optJSONArray("peserta");
            if (pa != null) {
                while (rows.size() < pa.length()) addRow();
                while (rows.size() > Math.max(1, pa.length())) hapusRow(rows.get(rows.size() - 1));
                for (int i = 0; i < rows.size(); i++) {
                    PRow r = rows.get(i);
                    JSONObject p = i < pa.length() ? pa.getJSONObject(i) : null;
                    r.sp.setValue(p == null ? "" : p.optString("nama"));
                    r.sp.fire();
                    String s = p == null ? "" : p.optString("ttd");
                    if (!s.isEmpty()) setTtd(r, new Model.Img(Base64.decode(s, Base64.NO_WRAP), "png", p.optInt("w", 1), p.optInt("h", 1)));
                    else setTtd(r, null);
                }
            }
            JSONArray fa = d.optJSONArray("foto");
            for (int i = 0; i < 2; i++) {
                String s = fa == null ? "" : fa.optString(i);
                if (s.isEmpty()) { fotoBytes[i] = null; fotoView[i].setImageBitmap(null); }
                else {
                    fotoBytes[i] = Base64.decode(s, Base64.NO_WRAP);
                    fotoView[i].setImageBitmap(BitmapFactory.decodeByteArray(fotoBytes[i], 0, fotoBytes[i].length));
                }
            }
            updateNoDok();
            toast("Draft dimuat");
        } catch (Exception e) { toast("Draft gagal dimuat"); }
    }

    // ---------- model & hasil ----------
    Model.Img logoImg() {
        try {
            InputStream in = getResources().openRawResource(R.drawable.logo_retail);
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            in.close();
            byte[] b = bo.toByteArray();
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(b, 0, b.length, o);
            return new Model.Img(b, "png", o.outWidth, o.outHeight);
        } catch (Exception e) { return null; }
    }

    Model buatModel(boolean ttd) {
        Model m = new Model();
        String iso = tglIso.get(spTanggal.getSelectedItemPosition());
        String sh = Data.SHIFT[spShift.getSelectedItemPosition() - 1];
        m.tgl = Data.tglPanjang(iso);
        m.no = sh.replaceFirst("(?i)^Shift\\s*", "");
        m.nomorDok = Data.nomorDokumen(iso, sh);
        m.dipimpin = spDipimpin.value();
        m.kashift = spKa.value();
        m.dicatat = spDicatat.value();
        m.topik = etTopik.getText().toString();
        m.kendala = etKendala.getText().toString();
        m.denganTtd = ttd;
        m.logoDisetujui = cbLogo.isChecked();
        m.minPeserta = 0;
        for (PRow r : rows) {
            if (r.sp.value().isEmpty() || m.peserta.size() >= m.ttd.length) continue; // tidak ada baris kosong
            m.ttd[m.peserta.size()] = r.ttd;
            m.peserta.add(new String[]{r.sp.value(), Data.jabatanDari(r.sp.value())});
        }
        for (String s : materi) m.materi.add(s.trim());
        for (String s : hsse) m.hsse.add(s.trim());
        m.logo = logoImg();
        for (int i = 0; i < 2; i++) {
            if (fotoBytes[i] == null) continue;
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(fotoBytes[i], 0, fotoBytes[i].length, o);
            m.foto[i] = new Model.Img(fotoBytes[i], "jpg", Math.max(1, o.outWidth), Math.max(1, o.outHeight));
        }
        return m;
    }

    boolean valid() {
        if (spShift.getSelectedItemPosition() <= 0) { toast("Pilih shift dulu"); return false; }
        if (spDipimpin.value().isEmpty()) { toast("Pilih yang memimpin"); return false; }
        if (spDicatat.value().isEmpty()) { toast("Pilih pencatat"); return false; }
        if (spKa.value().isEmpty()) { toast("Pilih Ka. Shift"); return false; }
        boolean ada = false;
        for (PRow r : rows) if (!r.sp.value().isEmpty()) ada = true;
        if (!ada) { toast("Pilih minimal satu peserta"); return false; }
        return true;
    }

    void lihatHasil() {
        if (!valid()) return;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);
        root.setPadding(dp(12), dp(16), dp(12), dp(8));

        root.addView(tv("Hasil cetak (1 halaman A4)", 18, true, BLUE));
        RadioGroup rg = new RadioGroup(this);
        final RadioButton rb1 = new RadioButton(this);
        rb1.setText("Cetak dengan tanda tangan");
        final RadioButton rb2 = new RadioButton(this);
        rb2.setText("Cetak tanpa tanda tangan");
        rb1.setId(View.generateViewId());
        rb2.setId(View.generateViewId());
        rg.addView(rb1);
        rg.addView(rb2);
        (denganTtd ? rb1 : rb2).setChecked(true);
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup g, int id) {
                denganTtd = (id == rb1.getId());
                renderPreview();
            }
        });
        root.addView(rg);

        LinearLayout b1 = new LinearLayout(this);
        b1.addView(btn("Simpan PDF", new View.OnClickListener() { public void onClick(View v) { simpan("pdf"); } }), new LinearLayout.LayoutParams(0, -2, 1));
        b1.addView(btn("Simpan Word", new View.OnClickListener() { public void onClick(View v) { simpan("docx"); } }), new LinearLayout.LayoutParams(0, -2, 1));
        b1.addView(btn("Simpan Excel", new View.OnClickListener() { public void onClick(View v) { simpan("xlsx"); } }), new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(b1);
        LinearLayout b2 = new LinearLayout(this);
        b2.addView(btn("Cetak", new View.OnClickListener() { public void onClick(View v) { cetak(); } }), new LinearLayout.LayoutParams(0, -2, 1));
        b2.addView(btn("Perbesar/kecilkan", new View.OnClickListener() { public void onClick(View v) { zoomed = !zoomed; renderPreview(); } }), new LinearLayout.LayoutParams(0, -2, 1));
        b2.addView(btn("Kembali", new View.OnClickListener() { public void onClick(View v) { setContentView(formRoot); } }), new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(b2);

        ScrollView vs = new ScrollView(this);
        HorizontalScrollView hs = new HorizontalScrollView(this);
        previewIv = new ImageView(this);
        previewIv.setAdjustViewBounds(true);
        hs.addView(previewIv);
        vs.addView(hs);
        root.addView(vs, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        renderPreview();
    }

    void renderPreview() {
        try {
            lastResult = SheetPainter.layout(buatModel(denganTtd));
            int w = zoomed ? 2000 : 1100;
            Bitmap bm = SheetPainter.preview(lastResult, w);
            int shownW = zoomed ? Math.round(getResources().getDisplayMetrics().widthPixels * 2.2f) : getResources().getDisplayMetrics().widthPixels - dp(24);
            previewIv.setLayoutParams(new FrameLayout.LayoutParams(shownW, Math.round(shownW * Layout.PH / Layout.PW)));
            previewIv.setImageBitmap(bm);
        } catch (Exception e) { toast("Gagal membuat pratinjau: " + e.getMessage()); }
    }

    String namaFile(String ext) {
        String iso = tglIso.get(spTanggal.getSelectedItemPosition());
        return "Briefing_Shift" + spShift.getSelectedItemPosition() + "_" + iso + (denganTtd ? "_TTD" : "_tanpa-TTD") + "." + ext;
    }

    byte[] buatFile(String fmt) throws Exception {
        Model m = buatModel(denganTtd);
        if (fmt.equals("pdf")) return SheetPainter.pdf(SheetPainter.layout(m));
        if (fmt.equals("docx")) return DocxWriter.build(m);
        return XlsxWriter.build(m);
    }

    void simpan(String fmt) {
        pendingFmt = fmt;
        Intent it = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        it.addCategory(Intent.CATEGORY_OPENABLE);
        it.setType(fmt.equals("pdf") ? "application/pdf"
            : fmt.equals("docx") ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            : "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        it.putExtra(Intent.EXTRA_TITLE, namaFile(fmt));
        startActivityForResult(it, REQ_SAVE);
    }

    void cetak() {
        final byte[] pdf;
        try { pdf = SheetPainter.pdf(SheetPainter.layout(buatModel(denganTtd))); }
        catch (Exception e) { toast("Gagal menyiapkan cetak"); return; }
        PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
        final String nama = namaFile("pdf");
        pm.print(nama, new PrintDocumentAdapter() {
            @Override public void onLayout(PrintAttributes o, PrintAttributes n, CancellationSignal cs, LayoutResultCallback cb, Bundle extras) {
                if (cs.isCanceled()) { cb.onLayoutCancelled(); return; }
                cb.onLayoutFinished(new PrintDocumentInfo.Builder(nama).setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(1).build(), true);
            }
            @Override public void onWrite(PageRange[] pages, ParcelFileDescriptor dest, CancellationSignal cs, WriteResultCallback cb) {
                try {
                    FileOutputStream os = new FileOutputStream(dest.getFileDescriptor());
                    os.write(pdf);
                    os.flush();
                    cb.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});
                } catch (Exception e) { cb.onWriteFailed(e.getMessage()); }
            }
        }, null);
    }
}
