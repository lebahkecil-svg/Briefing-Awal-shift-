package id.spbu.briefing;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Data {
    public static final String ADMIN_NAME = "Budi Prasetyo";
    public static final String ADMIN_PW = "081978";
    public static final int JUMLAH_PESERTA = 7;

    public static final String[] KA_SHIFT = {"Budi Prasetyo", "Hoeri Rozikin", "Perdi Saputra", "Yayan Aditya Putra"};
    public static final Map<String, String[]> PEKERJA = new LinkedHashMap<>();
    static {
        PEKERJA.put("Operator", new String[]{
            "Muhammad Sadewo", "Nurhasanah", "Falah Shofwansyah", "Laura Firnanda Aurora",
            "Nadila Ovtavia Putri P", "Regina Ref viana", "Zahra Nafilah", "Ham Lesipela",
            "Lutfi Dwi Arianto", "Lutfi Nizal Ramadhan", "Fawaz Aufa Nur Rohman", "Rangga Aditya",
            "Debi S", "Chairul Imam", "Mulyana Kumbara"});
        PEKERJA.put("Cleaning Service", new String[]{"Sifa'udin", "Slamet Yulianto", "Siswanto"});
        PEKERJA.put("Bright Store", new String[]{"Deni", "Ismi"});
        PEKERJA.put("Security", new String[]{"Muhammad Sadeli", "Yuyung Wanjung Nugraha", "Perta Saiful", "Edi S"});
    }

    public static final String[] MATERI_DEFAULT = {
        "Melakukan Pengecekan suhu badan dengan termometer",
        "Mengkonsumsi buah dan vitamin",
        "Tawarkan promo My pertamina",
        "Wajib menjalankan SOP",
        "Ingatkan potensi bahaya",
        "Penunjukan angka NOL.",
        "Setorkan uang ke ka shift jika sudah banyak",
        "Jaga kebersihan pulau",
        "Ucapkan salam & terimakasih",
        "Dilakukan penolakan untuk motor-motor atau mobil indikasi pelangsir/penjualan eceran",
        "Mencatat plat no kendaraan yang terindikasi melakukan penimbunan atau pengecer dengan tujuan tidak melakukan pengisian secara berulang."};
    public static final String[] HSSE_DEFAULT = {
        "Pemasangan Setikon saat kendaraan datang",
        "Matikan Mesin kendaraan",
        "Dilarang merokok",
        "Dilarang menggunakan kamera diarea pulau",
        "Dilarang menggunakan HP saat pengisian",
        "Turun dari kendaraan pada saat pengisian untuk roda 2"};

    public static final String[] SHIFT = {"Shift 1", "Shift 2", "Shift 3"};
    public static final String[] HARI = {"Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"};
    public static final String[] BULAN = {"Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"};
    public static final String[] ROMAWI = {"I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"};

    /** Semua nama berurutan: Ka. Shift, lalu tiap jabatan (urut abjad). Judul grup diawali "§". */
    public static List<String> semuaNama() {
        List<String> out = new ArrayList<>();
        out.add("§Ka. Shift");
        String[] k = KA_SHIFT.clone();
        Arrays.sort(k, String.CASE_INSENSITIVE_ORDER);
        out.addAll(Arrays.asList(k));
        for (Map.Entry<String, String[]> e : PEKERJA.entrySet()) {
            out.add("§" + e.getKey());
            String[] v = e.getValue().clone();
            Arrays.sort(v, String.CASE_INSENSITIVE_ORDER);
            out.addAll(Arrays.asList(v));
        }
        return out;
    }

    public static String jabatanDari(String nama) {
        if (nama == null || nama.isEmpty()) return "";
        for (String k : KA_SHIFT) if (k.equals(nama)) return "Ka. Shift";
        for (Map.Entry<String, String[]> e : PEKERJA.entrySet())
            for (String v : e.getValue()) if (v.equals(nama)) return e.getKey();
        return "";
    }

    /** 3 angka (0 + tanggal) / FBAS + nomor shift / 31.107.02 / bulan romawi / tahun. iso = yyyy-mm-dd */
    public static String nomorDokumen(String iso, String shift) {
        String[] t = iso.split("-");
        String sh = shift == null ? "" : shift.replaceFirst("(?i)^Shift\\s*", "");
        return "0" + t[2] + "/FBAS" + sh + "/31.107.02/" + ROMAWI[Integer.parseInt(t[1]) - 1] + "/" + t[0];
    }

    public static String tglPanjang(String iso) {
        String[] t = iso.split("-");
        return Integer.parseInt(t[2]) + " " + BULAN[Integer.parseInt(t[1]) - 1] + " " + t[0];
    }
}
