package id.spbu.briefing;

import java.util.ArrayList;
import java.util.List;

/** Model dokumen untuk lembar keluaran (tanpa kelas Android supaya bisa diuji di JVM). */
public class Model {
    public static class Img {
        public byte[] bytes;
        public String type; // "png" atau "jpg"
        public int w, h;
        public Object cache; // dipakai pelukis (Bitmap)
        public Img(byte[] b, String t, int w, int h) { bytes = b; type = t; this.w = w; this.h = h; }
    }

    public String tgl = "", no = "", nomorDok = "", dipimpin = "", kashift = "", dicatat = "", topik = "", kendala = "";
    public List<String[]> peserta = new ArrayList<>(); // {nama, jabatan}
    public int minPeserta = 0;
    public boolean denganTtd = true;
    public boolean logoDisetujui = false;
    public List<String> materi = new ArrayList<>();
    public List<String> hsse = new ArrayList<>();
    public Img logo;
    public Img[] ttd = new Img[64];
    public Img[] foto = new Img[2];

    /** Posisi kata "RETAIL" (merah) pada logo, sebagai pecahan lebar logo. */
    public static final float RETAIL_X0 = 0.377f, RETAIL_X1 = 0.709f;
    public static final String SUB_LOGO = "SPBU COCO 31.107.02 SAMANHUDI";

    public int jumlahBaris() { return Math.max(minPeserta, peserta.size()); }
}
