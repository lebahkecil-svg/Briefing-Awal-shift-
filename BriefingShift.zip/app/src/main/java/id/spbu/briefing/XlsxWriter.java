package id.spbu.briefing;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Penulis .xlsx manual (OOXML). Lembar diset fit-to-page A4 portrait = 1 halaman. Tanpa kelas Android. */
public class XlsxWriter {
    // kolom: batas persen 0,7,33,37,56,62,63,78,100
    static final float[] PCT = {7, 26, 4, 19, 6, 1, 15, 22};
    static final int TOTAL_PX = 660;
    static final int NC = 8;

    static class CellD { String text; int font, border, h, v, wrap; }
    static class Place { int r1, c1, r2, c2; Model.Img img; String mode; int idx, count; }

    final Model m;
    final int[] colPx = new int[NC];
    final TreeMap<Integer, TreeMap<Integer, CellD>> grid = new TreeMap<>();
    final List<int[]> merges = new ArrayList<>();
    final Map<Integer, Float> rowPt = new HashMap<>();
    final List<String> fonts = new ArrayList<>();
    final List<String> borders = new ArrayList<>();
    final List<String> xfs = new ArrayList<>();
    final List<Place> places = new ArrayList<>();
    final List<Model.Img> media = new ArrayList<>();

    XlsxWriter(Model m) {
        this.m = m;
        int sum = 0;
        for (int i = 0; i < NC; i++) { colPx[i] = Math.round(PCT[i] * TOTAL_PX / 100f); sum += colPx[i]; }
        colPx[NC - 1] += TOTAL_PX - sum;
        fonts.add(font(false, false, 10, null));
        borders.add(border(0));
    }

    static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    static String font(boolean b, boolean u, int size, String color) {
        return "<font>" + (b ? "<b/>" : "") + (u ? "<u/>" : "") + "<sz val=\"" + size + "\"/><color rgb=\"" + (color == null ? "FF000000" : color) + "\"/><name val=\"Times New Roman\"/><family val=\"1\"/></font>";
    }

    // edges: 1=atas 2=bawah 4=kiri 8=kanan
    static String border(int e) {
        String t = "<border>";
        t += (e & 4) != 0 ? "<left style=\"thin\"><color rgb=\"FF333333\"/></left>" : "<left/>";
        t += (e & 8) != 0 ? "<right style=\"thin\"><color rgb=\"FF333333\"/></right>" : "<right/>";
        t += (e & 1) != 0 ? "<top style=\"thin\"><color rgb=\"FF333333\"/></top>" : "<top/>";
        t += (e & 2) != 0 ? "<bottom style=\"thin\"><color rgb=\"FF333333\"/></bottom>" : "<bottom/>";
        return t + "<diagonal/></border>";
    }

    static int reg(List<String> l, String s) {
        int i = l.indexOf(s);
        if (i < 0) { l.add(s); i = l.size() - 1; }
        return i;
    }

    // h: 0 kiri 1 tengah ; v: 0 atas 1 tengah ; wrap 0/1
    void put(int r1, int c1, int r2, int c2, String text, boolean b, boolean u, int size, String color, int h, int v, int wrap, boolean box) {
        int fid = reg(fonts, font(b, u, size, color));
        for (int r = r1; r <= r2; r++) {
            for (int c = c1; c <= c2; c++) {
                int e = 0;
                if (box) {
                    if (r == r1) e |= 1;
                    if (r == r2) e |= 2;
                    if (c == c1) e |= 4;
                    if (c == c2) e |= 8;
                }
                CellD d = new CellD();
                d.font = fid; d.border = reg(borders, border(e)); d.h = h; d.v = v; d.wrap = wrap;
                d.text = (r == r1 && c == c1) ? text : null;
                grid.computeIfAbsent(r, k -> new TreeMap<>()).put(c, d);
            }
        }
        if (r1 != r2 || c1 != c2) merges.add(new int[]{r1, c1, r2, c2});
    }

    void T(int r1, int c1, int r2, int c2, String text, boolean b) { put(r1, c1, r2, c2, text, b, false, 10, null, 0, 0, 1, true); }
    void Tc(int r1, int c1, int r2, int c2, String text, boolean b) { put(r1, c1, r2, c2, text, b, false, 10, null, 1, 0, 1, true); }
    void Tm(int r1, int c1, int r2, int c2, String text, boolean b, boolean center) { put(r1, c1, r2, c2, text, b, false, 10, null, center ? 1 : 0, 1, 1, true); }

    /** "Label<spasi>: nilai" dengan titik dua rata pada lebar target (em, Times 10 pt). */
    static String kv(String label, String value, float targetEm) {
        float w = Data.approxWidth(label, false);
        int n = Math.max(0, Math.round((targetEm - w) / 0.25f));
        StringBuilder sb = new StringBuilder(label);
        for (int i = 0; i < n; i++) sb.append(' ');
        sb.append(':');
        if (value != null && !value.isEmpty()) sb.append(' ').append(value);
        return sb.toString();
    }

    static float maxEm(String... l) {
        float m = 0;
        for (String x : l) m = Math.max(m, Data.approxWidth(x, false));
        return m + 0.1f;
    }

    void rowH(int r, float pt) { Float o = rowPt.get(r); if (o == null || pt > o) rowPt.put(r, pt); }

    static int lines(String t, float charsPerLine) {
        int n = 0;
        for (String p : (t == null ? "" : t).split("\n", -1)) n += Math.max(1, (int) Math.ceil(p.length() / charsPerLine));
        return n;
    }

    float pxW(int c1, int c2) { float s = 0; for (int c = c1; c <= c2; c++) s += colPx[c]; return s; }

    void layout() {
        int r = 0;
        put(r, 0, r, NC - 1, "SHIFT " + m.no, true, false, 12, null, 0, 1, 0, false);
        rowH(r, 20); r++;

        // Kepala
        int h0 = r;
        put(h0, 0, h0 + 1, 5, "BRIEFING PERGANTIAN SHIFT", true, false, 11, null, 0, 1, 0, true);
        float e3 = maxEm("No. Dokumen", "Revisi", "Disetujui"), e1 = maxEm("Tanggal", "Shift"), e2 = maxEm("Dipimpin", "KA. SHIFT", "DICATAT");
        put(h0, 6, h0, 7, kv("No. Dokumen", m.nomorDok, e3), false, false, 9, null, 0, 0, 1, true);
        T(h0 + 1, 6, h0 + 1, 7, kv("Revisi", "", e3), true);
        rowH(h0, 22); rowH(h0 + 1, 22);
        r += 2;
        int a = r;
        T(a, 0, a + 1, 1, kv("Tanggal", m.tgl, e1) + "\n" + kv("Shift", m.no, e1), false);
        T(a, 2, a, 5, kv("Dipimpin", m.dipimpin, e2), false);
        T(a + 1, 2, a + 1, 5, kv("KA. SHIFT", m.kashift, e2), false);
        T(a + 2, 0, a + 2, 1, "No SPBU: 31-10702\nLokasi SPBU: Jl. Samanhudi\n      COCO SAMANHUDI", true);
        T(a + 2, 2, a + 2, 5, kv("DICATAT", m.dicatat, e2), false);
        put(a, 6, a, 7, kv("Disetujui", "", e3), true, false, 10, null, 0, 0, 0, true);
        if (m.logoDisetujui && m.logo != null) {
            float[] sd = stampDims();
            float span = (Model.RETAIL_X1 - Model.RETAIL_X0) * sd[0] * 0.75f;      // pt
            float em = Data.approxWidth(Model.SUB_LOGO, false);
            float sz = Math.max(4f, span / em);
            float cx = ((pxW(6, 7) - sd[0]) / 2f + (Model.RETAIL_X0 + Model.RETAIL_X1) / 2f * sd[0]) * 0.75f; // pt
            float startPt = cx - em * sz / 2f;
            int sp = Math.max(0, Math.round(startPt / (0.25f * sz)));
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < sp; i++) sb.append(' ');
            put(a + 1, 6, a + 1, 7, sb + Model.SUB_LOGO, false, false, Math.max(4, Math.round(sz)), null, 0, 2, 0, true);
        } else {
            put(a + 1, 6, a + 1, 7, "", false, false, 10, null, 0, 0, 0, true);
        }
        put(a + 2, 6, a + 2, 7, "FERLIQ PONTUMIKA YUDITAMA\nBUH SPBU", true, false, 10, null, 1, 1, 1, true);
        rowH(a, 20); rowH(a + 1, 36); rowH(a + 2, 42);
        // garis bawah nama
        if (m.logo != null) { addPlace(h0, 0, h0 + 1, 5, m.logo, "logo", 0, 1); }
        if (m.logoDisetujui && m.logo != null) { addPlace(a + 1, 6, a + 1, 7, m.logo, "stamp", 0, 1); }
        r += 3;

        // Topik
        T(r, 0, r, NC - 1, "Topik Bahasan :", true); rowH(r, 16); r++;
        T(r, 0, r, NC - 1, m.topik, false);
        rowH(r, Math.max(44, 13.5f * lines(m.topik, 95) + 6)); r++;

        // Peserta
        put(r, 0, r, 2, "Peserta :", true, false, 10, null, 0, 1, 0, true);
        put(r, 3, r, 3, "Jabatan", true, false, 10, null, 1, 1, 0, true);
        put(r, 4, r, 7, "Tanda Tangan", true, false, 10, null, 1, 1, 0, true);
        rowH(r, 18); r++;
        int n = m.jumlahBaris();
        for (int i = 0; i < n; i++) {
            String[] p = i < m.peserta.size() ? m.peserta.get(i) : null;
            int rr = r + i;
            put(rr, 0, rr, 0, String.valueOf(i + 1), true, false, 10, null, 1, 1, 0, true);
            put(rr, 1, rr, 2, p != null ? p[0] : "", false, false, 10, null, 0, 1, 1, true);
            put(rr, 3, rr, 3, p != null ? p[1] : "", false, false, 10, null, 0, 1, 1, true);
            rowH(rr, 22);
        }
        for (int i = 0; i < n; i += 2) {
            int rr = r + i;
            int last = i + 1 < n ? rr + 1 : rr;
            if (i + 1 < n) {
                put(rr, 4, last, 6, String.valueOf(i + 1), false, false, 6, "FF555555", 0, 0, 0, true);
                put(rr, 7, last, 7, String.valueOf(i + 2), false, false, 6, "FF555555", 0, 0, 0, true);
                if (m.denganTtd) {
                    if (i < m.ttd.length && m.ttd[i] != null) addPlace(rr, 4, last, 6, m.ttd[i], "sig", 0, 1);
                    if (i + 1 < m.ttd.length && m.ttd[i + 1] != null) addPlace(rr, 7, last, 7, m.ttd[i + 1], "sig", 0, 1);
                }
            } else {
                // ganjil: peserta terakhir, kolom tanda tangan digabung dan baris 1,5x
                put(rr, 4, rr, 7, String.valueOf(i + 1), false, false, 6, "FF555555", 0, 0, 0, true);
                rowH(rr, 33);
                if (m.denganTtd && i < m.ttd.length && m.ttd[i] != null) addPlace(rr, 4, rr, 7, m.ttd[i], "sig", 0, 1);
            }
        }
        r += n;

        // Ringkasan
        T(r, 0, r, NC - 1, "Ringkasan Materi Briefing :", true); rowH(r, 16); r++;
        int nm = m.materi.size(), nh = m.hsse.size();
        int t5 = r;
        float leftChars = pxW(0, 4) / 6.4f;
        for (int k = 0; k < nm; k++) {
            put(t5 + k, 0, t5 + k, 4, (k + 1) + ".  " + m.materi.get(k), false, false, 10, null, 0, 0, 1, true);
            rowH(t5 + k, Math.max(15, 13.5f * lines((k + 1) + ".  " + m.materi.get(k), leftChars) + 3));
        }
        put(t5 + nm, 0, t5 + nm, 4, "", false, false, 10, null, 0, 0, 0, true);
        rowH(t5 + nm, 15);
        Tc(t5, 5, t5, 7, "Dokumentasi", true);
        int hs = t5 + nm + 1;
        int kr = hs + 1 + nh;
        if (nm >= 1) put(t5 + 1, 5, t5 + nm, 7, "", false, false, 10, null, 0, 0, 0, true);
        put(hs, 0, hs, 4, "Masukan Aspek HSSE :", true, false, 10, null, 0, 0, 0, true);
        rowH(hs, 15);
        for (int k = 0; k < nh; k++) {
            put(hs + 1 + k, 0, hs + 1 + k, 4, "*" + m.hsse.get(k), false, false, 10, null, 0, 0, 1, true);
            rowH(hs + 1 + k, Math.max(15, 13.5f * lines("*" + m.hsse.get(k), leftChars) + 3));
        }
        put(kr, 0, kr, 4, "Kendala Aspek HSSE :", true, false, 10, null, 0, 0, 0, true);
        rowH(kr, 15);
        put(kr + 1, 0, kr + 1, 4, m.kendala, false, false, 10, null, 0, 0, 1, true);
        rowH(kr + 1, Math.max(26, 13.5f * lines(m.kendala, leftChars) + 4));
        put(hs, 5, kr + 1, 7, "", false, false, 10, null, 0, 0, 0, true);
        // foto 1 mengisi kotak di samping materi, foto 2 kotak di samping HSSE
        if (nm >= 1 && m.foto[0] != null) addPlace(t5 + 1, 5, t5 + nm, 7, m.foto[0], "foto", 0, 1);
        if (m.foto[1] != null) addPlace(hs, 5, kr + 1, 7, m.foto[1], "foto", 1, 1);
        lastRow = kr + 1;
    }

    int lastRow;

    void addPlace(int r1, int c1, int r2, int c2, Model.Img img, String mode, int idx, int count) {
        Place p = new Place(); p.r1 = r1; p.c1 = c1; p.r2 = r2; p.c2 = c2; p.img = img; p.mode = mode; p.idx = idx; p.count = count;
        places.add(p);
        if (media.indexOf(img) < 0) media.add(img);
    }

    /** Ukuran logo (px) di kotak Disetujui: ruang bawah disisakan untuk tulisan kecil. */
    float[] stampDims() {
        float w = pxW(6, 7) - 12f;
        float h = 36f / 0.75f - 14f;
        float[] f = Layout.fitSize(m.logo.w, m.logo.h, w, h);
        return f;
    }

    float rowHeightPt(int r) { Float v = rowPt.get(r); return v == null ? 15f : v; }
    float rowTopPx(int r) { float s = 0; for (int i = 0; i < r; i++) s += rowHeightPt(i) / 0.75f; return s; }
    float colLeftPx(int c) { float s = 0; for (int i = 0; i < c; i++) s += colPx[i]; return s; }

    String sheetXml() {
        StringBuilder s = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">");
        s.append("<sheetPr><pageSetUpPr fitToPage=\"1\"/></sheetPr>");
        s.append("<dimension ref=\"A1:H").append(lastRow + 1).append("\"/>");
        s.append("<sheetViews><sheetView workbookViewId=\"0\" showGridLines=\"0\"/></sheetViews><sheetFormatPr defaultRowHeight=\"15\"/><cols>");
        for (int c = 0; c < NC; c++) {
            float w = colPx[c] / 7f;
            s.append("<col min=\"").append(c + 1).append("\" max=\"").append(c + 1).append("\" width=\"").append(String.format(java.util.Locale.US, "%.2f", w)).append("\" customWidth=\"1\"/>");
        }
        s.append("</cols><sheetData>");
        for (Map.Entry<Integer, TreeMap<Integer, CellD>> re : grid.entrySet()) {
            int r = re.getKey();
            s.append("<row r=\"").append(r + 1).append("\" ht=\"").append(String.format(java.util.Locale.US, "%.1f", rowHeightPt(r))).append("\" customHeight=\"1\">");
            for (Map.Entry<Integer, CellD> ce : re.getValue().entrySet()) {
                CellD d = ce.getValue();
                String ref = "" + (char) ('A' + ce.getKey()) + (r + 1);
                int xf = reg(xfs, "<xf numFmtId=\"0\" fontId=\"" + d.font + "\" fillId=\"0\" borderId=\"" + d.border + "\" xfId=\"0\" applyFont=\"1\" applyBorder=\"1\" applyAlignment=\"1\"><alignment horizontal=\""
                    + (d.h == 1 ? "center" : "left") + "\" vertical=\"" + (d.v == 1 ? "center" : d.v == 2 ? "bottom" : "top") + "\"" + (d.wrap == 1 ? " wrapText=\"1\"" : "") + "/></xf>");
                if (d.text == null || d.text.isEmpty()) s.append("<c r=\"").append(ref).append("\" s=\"").append(xf).append("\"/>");
                else s.append("<c r=\"").append(ref).append("\" s=\"").append(xf).append("\" t=\"inlineStr\"><is><t xml:space=\"preserve\">").append(esc(d.text)).append("</t></is></c>");
            }
            s.append("</row>");
        }
        s.append("</sheetData>");
        if (!merges.isEmpty()) {
            s.append("<mergeCells count=\"").append(merges.size()).append("\">");
            for (int[] g : merges)
                s.append("<mergeCell ref=\"").append((char) ('A' + g[1])).append(g[0] + 1).append(":").append((char) ('A' + g[3])).append(g[2] + 1).append("\"/>");
            s.append("</mergeCells>");
        }
        s.append("<printOptions horizontalCentered=\"1\"/><pageMargins left=\"0.4\" right=\"0.4\" top=\"0.4\" bottom=\"0.4\" header=\"0.2\" footer=\"0.2\"/>");
        s.append("<pageSetup paperSize=\"9\" orientation=\"portrait\" fitToWidth=\"1\" fitToHeight=\"1\"/>");
        if (!places.isEmpty()) s.append("<drawing r:id=\"rId1\"/>");
        s.append("</worksheet>");
        return s.toString();
    }

    String stylesXml() {
        StringBuilder s = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">");
        s.append("<fonts count=\"").append(fonts.size()).append("\">");
        for (String f : fonts) s.append(f);
        s.append("</fonts><fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill></fills>");
        s.append("<borders count=\"").append(borders.size()).append("\">");
        for (String b : borders) s.append(b);
        s.append("</borders><cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs><cellXfs count=\"").append(xfs.size()).append("\">");
        for (String x : xfs) s.append(x);
        s.append("</cellXfs><cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>");
        return s.toString();
    }

    static long emu(float px) { return Math.round(px * 9525.0); }

    String drawingXml() {
        StringBuilder s = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><xdr:wsDr xmlns:xdr=\"http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">");
        int id = 2;
        for (Place p : places) {
            float x0 = colLeftPx(p.c1), x1 = colLeftPx(p.c2 + 1), y0 = rowTopPx(p.r1), y1 = rowTopPx(p.r2 + 1);
            float w = x1 - x0, h = y1 - y0;
            float px, py, pw, ph;
            String crop = "";
            if (p.mode.equals("logo")) {
                float[] f = Layout.fitSize(p.img.w, p.img.h, 90, Math.min(32, h - 8));
                pw = f[0]; ph = f[1]; px = x1 - pw - 24; py = y0 + (h - ph) / 2;
            } else if (p.mode.equals("stamp")) {
                float[] f = stampDims();
                pw = f[0]; ph = f[1]; px = x0 + (w - pw) / 2; py = y0 + 2;
            } else if (p.mode.equals("sig")) {
                float[] f = Layout.fitSize(p.img.w, p.img.h, w - 8, h - 13);
                pw = f[0]; ph = f[1]; px = x0 + (w - pw) / 2; py = y0 + 10 + (h - 13 - ph) / 2;
            } else {
                pw = w - 2; ph = h - 2; px = x0 + 1; py = y0 + 1; // memenuhi kotak
                float sa = (float) p.img.w / p.img.h, ba = pw / ph;
                if (sa > ba) { int c = Math.round((1 - ba / sa) / 2 * 100000); crop = " l=\"" + c + "\" r=\"" + c + "\""; }
                else { int c = Math.round((1 - sa / ba) / 2 * 100000); crop = " t=\"" + c + "\" b=\"" + c + "\""; }
            }
            // ubah koordinat absolut ke (kolom, offset), (baris, offset)
            int col = 0; float cl = 0;
            for (int c = 0; c < NC; c++) { if (px >= cl && px < cl + colPx[c]) { col = c; break; } cl += colPx[c]; col = c; }
            int row = 0; float rt = 0;
            for (int r = 0; r <= lastRow; r++) { float rh = rowHeightPt(r) / 0.75f; if (py >= rt && py < rt + rh) { row = r; break; } rt += rh; row = r; }
            int mi = media.indexOf(p.img);
            s.append("<xdr:oneCellAnchor><xdr:from><xdr:col>").append(col).append("</xdr:col><xdr:colOff>").append(emu(px - cl)).append("</xdr:colOff><xdr:row>").append(row)
                .append("</xdr:row><xdr:rowOff>").append(emu(py - rt)).append("</xdr:rowOff></xdr:from><xdr:ext cx=\"").append(emu(pw)).append("\" cy=\"").append(emu(ph)).append("\"/>")
                .append("<xdr:pic><xdr:nvPicPr><xdr:cNvPr id=\"").append(id).append("\" name=\"Gambar ").append(id).append("\"/><xdr:cNvPicPr><a:picLocks noChangeAspect=\"1\"/></xdr:cNvPicPr></xdr:nvPicPr>")
                .append("<xdr:blipFill><a:blip r:embed=\"rId").append(mi + 1).append("\"/>").append(crop.isEmpty() ? "" : "<a:srcRect" + crop + "/>").append("<a:stretch><a:fillRect/></a:stretch></xdr:blipFill>")
                .append("<xdr:spPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"").append(emu(pw)).append("\" cy=\"").append(emu(ph)).append("\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></xdr:spPr></xdr:pic><xdr:clientData/></xdr:oneCellAnchor>");
            id++;
        }
        return s.append("</xdr:wsDr>").toString();
    }

    public static byte[] build(Model m) throws java.io.IOException {
        XlsxWriter x = new XlsxWriter(m);
        x.layout();
        String sheet = x.sheetXml();   // mengisi daftar xf
        String styles = x.stylesXml();
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        ZipOutputStream z = new ZipOutputStream(bo);
        boolean hasDraw = !x.places.isEmpty();
        DocxWriter.put(z, "[Content_Types].xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
            + "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/>"
            + "<Default Extension=\"png\" ContentType=\"image/png\"/><Default Extension=\"jpg\" ContentType=\"image/jpeg\"/>"
            + "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>"
            + "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>"
            + "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>"
            + (hasDraw ? "<Override PartName=\"/xl/drawings/drawing1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.drawing+xml\"/>" : "") + "</Types>");
        DocxWriter.put(z, "_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
            + "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
        DocxWriter.put(z, "xl/workbook.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">"
            + "<sheets><sheet name=\"Briefing\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>");
        DocxWriter.put(z, "xl/_rels/workbook.xml.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
            + "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/>"
            + "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>");
        DocxWriter.put(z, "xl/styles.xml", styles);
        DocxWriter.put(z, "xl/worksheets/sheet1.xml", sheet);
        if (hasDraw) {
            DocxWriter.put(z, "xl/worksheets/_rels/sheet1.xml.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                + "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing\" Target=\"../drawings/drawing1.xml\"/></Relationships>");
            DocxWriter.put(z, "xl/drawings/drawing1.xml", x.drawingXml());
            StringBuilder dr = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");
            for (int i = 0; i < x.media.size(); i++)
                dr.append("<Relationship Id=\"rId").append(i + 1).append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"../media/img").append(i)
                    .append(x.media.get(i).type.equals("png") ? ".png" : ".jpg").append("\"/>");
            DocxWriter.put(z, "xl/drawings/_rels/drawing1.xml.rels", dr.append("</Relationships>").toString());
            for (int i = 0; i < x.media.size(); i++) {
                Model.Img a = x.media.get(i);
                z.putNextEntry(new ZipEntry("xl/media/img" + i + (a.type.equals("png") ? ".png" : ".jpg")));
                z.write(a.bytes);
                z.closeEntry();
            }
        }
        z.close();
        return bo.toByteArray();
    }
}
