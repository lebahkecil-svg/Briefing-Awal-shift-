# Briefing Shift SPBU (Android native)

Form Briefing Pergantian Shift SPBU COCO 31.107.02 Samanhudi.
Output satu halaman A4 : PDF, Word, Excel, dan Cetak, dengan pilihan
"Cetak dengan tanda tangan" / "Cetak tanpa tanda tangan".

## Build lewat Chrome Android
1. Buat repository baru di GitHub, lalu "Add file > Upload files" dan unggah file ZIP ini (jangan diekstrak).
2. "Add file > Create new file", nama: `.github/workflows/build.yml`, tempel isi `workflow-salin/build.yml` (ada di dalam ZIP, atau salin dari chat), lalu Commit.
3. Tab Actions > Build APK > Run workflow. Setelah hijau, unduh APK dari bagian Releases (atau Artifacts).

## Catatan
- Password mode ubah ada di `Data.java` (ADMIN_PW). Tersimpan di dalam aplikasi, bukan rahasia kuat.
- Draft dan daftar materi/HSSE tersimpan di perangkat masing-masing.
