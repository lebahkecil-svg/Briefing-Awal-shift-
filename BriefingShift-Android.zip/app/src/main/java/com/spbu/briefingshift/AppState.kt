package com.spbu.briefingshift

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

const val DEFAULT_SPBU = "SPBU COCO 31.107.02 Samanhudi"

val ROLES = listOf("kashift", "pramuniaga", "sabright", "cs", "security")

val ROLE_TITLES = mapOf(
    "kashift" to "Ka. Shift",
    "pramuniaga" to "Pramuniaga",
    "sabright" to "SA Bright",
    "cs" to "Cleaning Service",
    "security" to "Security"
)

val DEFAULT_NAMES: Map<String, List<String>> = mapOf(
    "kashift" to listOf("Budi Prasetyo", "Hoeri Rozikin", "Yayan Aditya", "Perdi Saputra"),
    "pramuniaga" to listOf(
        "M.Nur Fadli", "Chairul Imam", "Regina Refiana", "Nadilla Octavia P", "Fawwaz Aufa N",
        "Lutfi Nizal R", "Laura Firnanda Aurora", "Mulyana Kumbara", "Rangga", "Zahra Nafilah",
        "Falah Shofwansyah", "M.Sadewo", "Deby", "Lutfi Dwi A", "Eka Ayu Permata"
    ),
    "sabright" to listOf("Muhammad Farhan", "Ria"),
    "cs" to listOf("Slamet Yulianto", "Siswanto", "Sifa'udin"),
    "security" to listOf("Muhammad Sadeli", "Yuyung Wanjung Nugraha", "Perta Saiful", "Raymond")
)

data class Person(val name: String = "", val temp: String = "36")
data class PramRow(val name: String = "", val temp: String = "36", val pulau: String = "")

fun isWeekend(): Boolean {
    val d = Calendar.getInstance().get(Calendar.DAY_OF_WEEK)
    return d == Calendar.SATURDAY || d == Calendar.SUNDAY
}

class AppState(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences("briefing", Context.MODE_PRIVATE)

    var spbuName by mutableStateOf(DEFAULT_SPBU)
    var shift by mutableStateOf("")
    var kashift by mutableStateOf(Person())
    var pulauEnabled by mutableStateOf(false)
    val pramuniaga = mutableStateListOf<PramRow>()
    var sabright by mutableStateOf(Person())
    var sabNi by mutableStateOf(isWeekend())
    var cs by mutableStateOf(Person())
    var security by mutableStateOf(Person())

    /** Daftar nama per peran (tersimpan permanen). */
    val names = mutableStateMapOf<String, List<String>>()

    /** Nama file foto/video di folder media aplikasi. */
    val media = mutableStateListOf<String>()

    init {
        load()
    }

    fun person(role: String): Person = when (role) {
        "kashift" -> kashift
        "sabright" -> sabright
        "cs" -> cs
        else -> security
    }

    fun setPerson(role: String, p: Person) {
        when (role) {
            "kashift" -> kashift = p
            "sabright" -> sabright = p
            "cs" -> cs = p
            else -> security = p
        }
    }

    fun namesOf(role: String): List<String> = names[role] ?: emptyList()

    // ---------- Pramuniaga ----------
    fun normalizeRows() {
        if (pramuniaga.isEmpty()) {
            pramuniaga.add(PramRow())
            return
        }
        val last = pramuniaga.last()
        val used = pramuniaga.count { it.name.isNotEmpty() }
        if (last.name.isNotEmpty() && used < namesOf("pramuniaga").size) pramuniaga.add(PramRow())
    }

    fun setPramName(idx: Int, name: String) {
        if (idx !in pramuniaga.indices) return
        pramuniaga[idx] = pramuniaga[idx].copy(name = name)
        if (name.isEmpty() && pramuniaga.size > 1 && idx != pramuniaga.lastIndex) pramuniaga.removeAt(idx)
        normalizeRows()
    }

    fun updatePram(idx: Int, row: PramRow) {
        if (idx in pramuniaga.indices) pramuniaga[idx] = row
    }

    fun removePram(idx: Int) {
        if (idx in pramuniaga.indices) pramuniaga.removeAt(idx)
        normalizeRows()
    }

    // ---------- Kelola nama ----------
    fun setNames(role: String, list: List<String>) {
        names[role] = list
        refresh()
    }

    /** Bersihkan pilihan yang namanya sudah dihapus dari daftar. */
    fun refresh() {
        listOf("kashift", "sabright", "cs", "security").forEach { r ->
            val p = person(r)
            if (p.name.isNotEmpty() && p.name !in namesOf(r)) setPerson(r, p.copy(name = ""))
        }
        val valid = namesOf("pramuniaga")
        val kept = pramuniaga.filter { it.name.isEmpty() || it.name in valid }
        pramuniaga.clear()
        pramuniaga.addAll(kept)
        normalizeRows()
    }

    // ---------- Media ----------
    fun addMedia(fileName: String) {
        if (fileName !in media) media.add(fileName)
    }

    fun removeMedia(fileName: String) {
        media.remove(fileName)
        MediaUtil.deleteFile(appContext, fileName)
    }

    // ---------- Reset ----------
    fun resetForm() {
        spbuName = DEFAULT_SPBU
        shift = ""
        kashift = Person()
        pulauEnabled = false
        pramuniaga.clear()
        pramuniaga.add(PramRow())
        sabright = Person()
        sabNi = isWeekend()
        cs = Person()
        security = Person()
        media.toList().forEach { MediaUtil.deleteFile(appContext, it) }
        media.clear()
    }

    // ---------- Persistensi ----------
    private fun personJson(p: Person) = JSONObject().put("name", p.name).put("temp", p.temp)

    private fun readPerson(o: JSONObject?): Person =
        if (o == null) Person() else Person(o.optString("name", ""), o.optString("temp", "36").ifBlank { "36" })

    fun snapshotAll(): List<String> {
        val st = JSONObject()
        st.put("spbuName", spbuName)
        st.put("shift", shift)
        st.put("kashift", personJson(kashift))
        st.put("pulauEnabled", pulauEnabled)
        val pr = JSONArray()
        pramuniaga.forEach {
            pr.put(JSONObject().put("name", it.name).put("temp", it.temp).put("pulau", it.pulau))
        }
        st.put("pramuniaga", pr)
        st.put("sabright", personJson(sabright))
        st.put("sabNi", sabNi)
        st.put("cs", personJson(cs))
        st.put("security", personJson(security))

        val nm = JSONObject()
        ROLES.forEach { r ->
            val arr = JSONArray()
            namesOf(r).forEach { arr.put(it) }
            nm.put(r, arr)
        }

        val md = JSONArray()
        media.forEach { md.put(it) }

        return listOf(st.toString(), nm.toString(), md.toString())
    }

    fun persist(snapshot: List<String>) {
        prefs.edit()
            .putString("state", snapshot[0])
            .putString("names", snapshot[1])
            .putString("media", snapshot[2])
            .apply()
    }

    private fun load() {
        // nama
        val savedNames = runCatching { JSONObject(prefs.getString("names", null) ?: "") }.getOrNull()
        ROLES.forEach { r ->
            val arr = savedNames?.optJSONArray(r)
            names[r] = if (arr != null) {
                (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() }
            } else {
                DEFAULT_NAMES.getValue(r)
            }
        }
        // isian form
        val o = runCatching { JSONObject(prefs.getString("state", null) ?: "") }.getOrNull()
        if (o != null) {
            spbuName = o.optString("spbuName", DEFAULT_SPBU).ifBlank { DEFAULT_SPBU }
            shift = o.optString("shift", "")
            kashift = readPerson(o.optJSONObject("kashift"))
            pulauEnabled = o.optBoolean("pulauEnabled", false)
            val arr = o.optJSONArray("pramuniaga")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val x = arr.optJSONObject(i) ?: continue
                    pramuniaga.add(
                        PramRow(
                            x.optString("name", ""),
                            x.optString("temp", "36").ifBlank { "36" },
                            x.optString("pulau", "")
                        )
                    )
                }
            }
            sabright = readPerson(o.optJSONObject("sabright"))
            sabNi = if (o.has("sabNi")) o.optBoolean("sabNi") else isWeekend()
            cs = readPerson(o.optJSONObject("cs"))
            security = readPerson(o.optJSONObject("security"))
        }
        // media (hanya yang filenya masih ada)
        val mArr = runCatching { JSONArray(prefs.getString("media", null) ?: "") }.getOrNull()
        if (mArr != null) {
            for (i in 0 until mArr.length()) {
                val n = mArr.optString(i)
                if (n.isNotBlank() && MediaUtil.file(appContext, n).exists()) media.add(n)
            }
        }
        refresh()
    }
}
