package com.spbu.briefingshift

import android.content.Context
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import java.io.File
import java.util.UUID

object MediaUtil {
    private val VIDEO_EXT = setOf("mp4", "3gp", "webm", "mkv", "mov", "m4v", "avi")

    fun dir(ctx: Context): File = File(ctx.filesDir, "media").also { it.mkdirs() }

    fun file(ctx: Context, name: String): File = File(dir(ctx), name)

    fun isVideo(name: String): Boolean = name.substringAfterLast('.', "").lowercase() in VIDEO_EXT

    fun mime(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
            ?: if (isVideo(name)) "video/*" else "image/*"
    }

    fun uriFor(ctx: Context, name: String): Uri =
        FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", file(ctx, name))

    fun newName(ext: String): String =
        "${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}.$ext"

    /** Salin foto/video pilihan galeri ke penyimpanan aplikasi supaya tetap ada. */
    fun importUri(ctx: Context, uri: Uri): String? {
        return try {
            val type = ctx.contentResolver.getType(uri) ?: ""
            val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(type)
                ?: if (type.startsWith("video")) "mp4" else "jpg"
            val name = newName(ext)
            ctx.contentResolver.openInputStream(uri)?.use { input ->
                file(ctx, name).outputStream().use { out -> input.copyTo(out) }
            } ?: return null
            name
        } catch (e: Exception) {
            null
        }
    }

    fun deleteFile(ctx: Context, name: String) {
        runCatching { file(ctx, name).delete() }
    }
}
