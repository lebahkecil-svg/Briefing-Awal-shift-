package com.spbu.briefingshift

import java.util.Calendar
import java.util.Locale

val MONTHS = listOf(
    "Januari", "Februari", "Maret", "April", "Mei", "Juni",
    "Juli", "Agustus", "September", "Oktober", "November", "Desember"
)
val DAYS = listOf("Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu")

fun formatTemp(v: String): String {
    val n = v.replace(',', '.').toDoubleOrNull() ?: return "36"
    return if (Math.round(n * 10) % 10L == 0L) String.format(Locale.US, "%.0f", n)
    else String.format(Locale.US, "%.1f", n)
}

private fun personLine(p: Person, prefix: String = ""): String =
    if (p.name.isNotEmpty()) "$prefix${p.name} – ${formatTemp(p.temp)}°C" else "-"

fun generateReport(s: AppState): String {
    val now = Calendar.getInstance()
    val tanggal = "${now.get(Calendar.DAY_OF_MONTH)} ${MONTHS[now.get(Calendar.MONTH)]} ${now.get(Calendar.YEAR)}"
    val jam = String.format(Locale.US, "%02d.%02d", now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE))
    val l = ArrayList<String>()

    l.add("📋 *BRIEFING SHIFT ${if (s.shift.isEmpty()) "-" else s.shift}*")
    l.add("🏪 *${s.spbuName}*")
    l.add("📅 $tanggal  🕐 $jam WIB")
    l.add("─".repeat(19))
    l.add("")
    l.add("👤 *Ka. Shift*")
    l.add("   ${personLine(s.kashift)}")
    l.add("")
    l.add("⛽ *Pramuniaga*")
    val filled = s.pramuniaga.filter { it.name.isNotEmpty() }
    if (filled.isEmpty()) {
        l.add("   -")
    } else {
        filled.forEachIndexed { i, r ->
            var line = "   ${i + 1}. ${r.name} – ${formatTemp(r.temp)}°C"
            if (s.pulauEnabled && r.pulau.isNotEmpty()) line += " (Pulau ${r.pulau})"
            l.add(line)
        }
    }
    l.add("")
    l.add("✨ *SA Bright*")
    var sab = "   ${personLine(s.sabright)}"
    if (s.sabright.name.isNotEmpty() && s.sabNi) sab += ", NI (08:00-16:00 WIB)"
    l.add(sab)
    l.add("")
    l.add("🧹 *Cleaning Service*")
    l.add("   ${personLine(s.cs, "Pak ")}")
    l.add("")
    l.add("🛡️ *Security*")
    l.add("   ${personLine(s.security, "Pak ")}")
    l.add("")
    l.add("─".repeat(20))
    l.add(MATERI_BRIEFING)
    l.add("")
    l.add(ATENSI)
    l.add("")
    l.add(SANKSI)
    l.add("")
    l.add("✅ Briefing selesai & dipahami seluruh peserta.")
    l.add("📍 ${s.spbuName}")
    return l.joinToString("\n")
}
