package com.spbu.briefingshift

// Teks baku laporan (disalin persis dari versi PWA)
val MATERI_BRIEFING = """📋 *MATERI BRIEFING:*
1️⃣ HSSE – utamakan keamanan & keselamatan
2️⃣ Terapkan SOP 5S dengan baik & benar
3️⃣ Jaga kerapian & kebersihan seragam & pulau
4️⃣ Utamakan Pertamax Turbo & Pertamina Dex
5️⃣ Tawarkan pembayaran via My Pertamina
6️⃣ Titip buang sampah kecil
7️⃣ Waspada uang palsu
8️⃣ Dilarang membawa/menggunakan HP di area pulau pompa/dispenser
9️⃣ Teliti input Non Cash (RFID/MyPertamina/EDC)
🔟 Hindari hal yang merugikan diri & perusahaan
1️⃣1️⃣ Waspada tangki siluman, tolak subsidi berulang
1️⃣2️⃣ Dilarang menggunakan/memakai uang penjualan"""

val ATENSI = """⚠️ *Atensi Penting !!!*
Dalam rangka memastikan penyaluran BBM subsidi berjalan dengan baik, benar, dan sesuai ketentuan, seluruh operator SPBU diwajibkan untuk:
1. Melaksanakan penyaluran BBM subsidi sesuai aturan dari pemerintah dan Pertamina.
2. Memastikan BBM subsidi hanya diberikan kepada konsumen yang berhak sesuai ketentuan yang berlaku.
3. Menggunakan sistem pengawasan yang telah ditetapkan (barcode/aplikasi resmi jika berlaku).
4. Menolak dengan sopan setiap pembelian yang tidak sesuai aturan.
5. Tidak melakukan praktik penimbunan, penyalahgunaan, atau kerja sama ilegal dalam bentuk apapun."""

val SANKSI = """⚖️ *Penegasan Sanksi (UU No. 22 Tahun 2001 Migas):*
   • Pidana penjara maksimal 6 (enam) tahun
   • Denda maksimal Rp60.000.000.000 (enam puluh miliar rupiah)
   Sanksi internal:
   • Pemutusan hubungan kerja (PHK)
   • Pencabutan izin kerja
   • Sanksi administratif lainnya"""

