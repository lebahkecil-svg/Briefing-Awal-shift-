package com.spbu.briefingshift

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.decode.VideoFrameDecoder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin
import kotlin.random.Random

// ---------- Warna (sama dengan versi PWA) ----------
private val Bg = Color(0xFF0B1220)
private val SurfaceC = Color(0xFF141E33)
private val Surface2 = Color(0xFF1C2940)
private val BorderC = Color(0xFF2A3B58)
private val TextC = Color(0xFFEAF1FB)
private val Muted = Color(0xFF8CA3C4)
private val Blue = Color(0xFF1E88FF)
private val Green = Color(0xFF15C97A)
private val Amber = Color(0xFFFFC542)
private val Red = Color(0xFFFF4757)
private val Teal = Color(0xFF27D3C9)
private val Purple = Color(0xFFB57BFF)
private val Led = Color(0xFF3CF6A0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        val dark = android.graphics.Color.parseColor("#0B1220")
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(dark),
            navigationBarStyle = SystemBarStyle.dark(dark)
        )
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Amber,
                    onPrimary = Color(0xFF1A0E00),
                    background = Bg,
                    surface = SurfaceC,
                    onSurface = TextC,
                    onBackground = TextC,
                    outline = BorderC
                )
            ) {
                Root()
            }
        }
    }
}

@Composable
fun Root() {
    val ctx = LocalContext.current
    val state = remember { AppState(ctx) }
    var showSplash by rememberSaveable { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        snapshotFlow { state.snapshotAll() }.collect { state.persist(it) }
    }
    LaunchedEffect(Unit) {
        if (showSplash) {
            delay(2800)
            showSplash = false
        }
    }

    Box(Modifier.fillMaxSize().background(Bg)) {
        Crossfade(targetState = showSplash, animationSpec = tween(600), label = "splash") { s ->
            if (s) SplashScreen() else MainScreen(state)
        }
    }
}

// =====================================================================
// SPLASH
// =====================================================================
@Composable
fun SplashScreen() {
    val stars = remember { List(60) { Triple(Random.nextFloat(), Random.nextFloat(), Random.nextFloat()) } }
    val transition = rememberInfiniteTransition(label = "stars")
    val t by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(3000, easing = LinearEasing), RepeatMode.Restart),
        label = "t"
    )
    val rot = remember { Animatable(0f) }
    val textAlpha = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        launch { rot.animateTo(360f, tween(1400)) }
        delay(900)
        textAlpha.animateTo(1f, tween(900))
    }
    val density = LocalDensity.current.density

    Box(
        Modifier.fillMaxSize().background(
            Brush.radialGradient(listOf(Color(0xFF1A0A2E), Bg, Color(0xFF000510)))
        ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            stars.forEach { (x, y, p) ->
                val a = (0.25f + 0.75f * abs(sin(((t + p) * PI).toFloat()))).coerceIn(0f, 1f)
                drawCircle(
                    Color.White.copy(alpha = a),
                    radius = 1.5.dp.toPx(),
                    center = Offset(x * size.width, y * size.height)
                )
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(
                painter = painterResource(R.drawable.team_photo),
                contentDescription = "Tim Shift",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(160.dp)
                    .graphicsLayer {
                        rotationY = rot.value
                        cameraDistance = 12f * density
                    }
                    .clip(CircleShape)
                    .border(3.dp, Amber, CircleShape)
            )
            Spacer(Modifier.height(28.dp))
            Text(
                "BRIEFING SHIFT",
                color = Amber,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 26.sp,
                letterSpacing = 3.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.graphicsLayer { alpha = textAlpha.value }.padding(horizontal = 16.dp)
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "SPBU COCO 31.107.02",
                color = Muted,
                fontSize = 14.sp,
                letterSpacing = 2.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.graphicsLayer { alpha = textAlpha.value }.padding(horizontal = 16.dp)
            )
        }
    }
}

// =====================================================================
// LAYAR UTAMA
// =====================================================================
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MainScreen(state: AppState) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val imageLoader = remember {
        ImageLoader.Builder(ctx).components { add(VideoFrameDecoder.Factory()) }.build()
    }

    var manageRole by remember { mutableStateOf<String?>(null) }
    var report by remember { mutableStateOf<String?>(null) }
    var confirmReset by remember { mutableStateOf(false) }
    var deleteMedia by remember { mutableStateOf<String?>(null) }
    var importing by remember { mutableStateOf(false) }
    var copied by remember { mutableStateOf(false) }
    var pendingCapture by rememberSaveable { mutableStateOf<String?>(null) }
    val bring = remember { BringIntoViewRequester() }

    fun toast(msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()

    fun importAll(uris: List<Uri>) {
        if (uris.isEmpty()) return
        importing = true
        scope.launch {
            val names = withContext(Dispatchers.IO) { uris.mapNotNull { MediaUtil.importUri(ctx, it) } }
            names.forEach { state.addMedia(it) }
            importing = false
            if (names.size < uris.size) toast("Sebagian file gagal ditambahkan")
        }
    }

    val pickPhotos = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia()) { importAll(it) }
    val pickVideos = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia()) { importAll(it) }

    fun finishCapture(ok: Boolean) {
        val n = pendingCapture
        pendingCapture = null
        if (n == null) return
        val f = MediaUtil.file(ctx, n)
        if (ok && f.exists() && f.length() > 0) state.addMedia(n) else MediaUtil.deleteFile(ctx, n)
    }

    val takePicture = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { finishCapture(it) }
    val captureVideo = rememberLauncherForActivityResult(ActivityResultContracts.CaptureVideo()) { finishCapture(it) }

    fun startCapture(video: Boolean) {
        val name = MediaUtil.newName(if (video) "mp4" else "jpg")
        try {
            MediaUtil.file(ctx, name).createNewFile()
            pendingCapture = name
            val uri = MediaUtil.uriFor(ctx, name)
            if (video) captureVideo.launch(uri) else takePicture.launch(uri)
        } catch (e: Exception) {
            MediaUtil.deleteFile(ctx, name)
            pendingCapture = null
            toast("Aplikasi kamera tidak ditemukan")
        }
    }

    fun openMedia(name: String) {
        try {
            val i = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(MediaUtil.uriFor(ctx, name), MediaUtil.mime(name))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            ctx.startActivity(i)
        } catch (e: Exception) {
            toast("Tidak ada aplikasi untuk membuka file ini")
        }
    }

    fun sendWhatsApp(text: String) {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        try {
            ctx.startActivity(Intent(i).setPackage("com.whatsapp"))
        } catch (e: ActivityNotFoundException) {
            try {
                ctx.startActivity(Intent(i).setPackage("com.whatsapp.w4b"))
            } catch (e2: ActivityNotFoundException) {
                ctx.startActivity(Intent.createChooser(i, "Kirim laporan"))
            }
        }
    }

    fun shareWithMedia(text: String) {
        try {
            val uris = ArrayList<Uri>(state.media.map { MediaUtil.uriFor(ctx, it) })
            clipboard.setText(AnnotatedString(text))
            val i = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "*/*"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                putExtra(Intent.EXTRA_TEXT, text)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                val cd = ClipData.newRawUri("media", uris[0])
                for (k in 1 until uris.size) cd.addItem(ClipData.Item(uris[k]))
                clipData = cd
            }
            toast("Teks laporan sudah disalin. Jika keterangan tidak muncul otomatis, tempel (paste) manual.")
            ctx.startActivity(Intent.createChooser(i, "Kirim laporan + foto/video"))
        } catch (e: Exception) {
            toast("Gagal membuka menu kirim")
        }
    }

    LaunchedEffect(copied) {
        if (copied) {
            delay(1500)
            copied = false
        }
    }
    LaunchedEffect(report) {
        if (report != null) {
            delay(120)
            runCatching { bring.bringIntoView() }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .systemBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
    ) {
        Header(state)

        Column(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // ----- Info -----
            SectionCard(Muted) {
                Label("Nama SPBU")
                OutlinedTextField(
                    value = state.spbuName,
                    onValueChange = { state.spbuName = it },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = fieldColors()
                )
                Label("Shift")
                Dropdown(
                    value = state.shift,
                    placeholder = "-- Pilih Shift --",
                    options = listOf("1", "2", "3"),
                    onSelect = { state.shift = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { "Shift $it" }
                )
            }

            // ----- Ka. Shift -----
            PersonCard(state, "kashift", "👤", Blue, onManage = { manageRole = it })

            // ----- Pramuniaga -----
            SectionCard(Green) {
                CardHeader("⛽", "Pramuniaga") { manageRole = "pramuniaga" }
                Row(
                    Modifier.fillMaxWidth().clickable { state.pulauEnabled = !state.pulauEnabled },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Switch(
                        checked = state.pulauEnabled,
                        onCheckedChange = { state.pulauEnabled = it },
                        colors = SwitchDefaults.colors(
                            checkedTrackColor = Green,
                            checkedThumbColor = Color.White,
                            uncheckedTrackColor = Surface2,
                            uncheckedThumbColor = Muted,
                            uncheckedBorderColor = BorderC
                        )
                    )
                    Spacer(Modifier.width(10.dp))
                    Text("Pulau (tampilkan pilihan P1–P4)", color = Muted, fontSize = 14.sp, modifier = Modifier.weight(1f))
                }
                state.pramuniaga.forEachIndexed { idx, row ->
                    PramRowView(state, idx, row)
                }
            }

            // ----- SA Bright -----
            PersonCard(state, "sabright", "✨", Amber, onManage = { manageRole = it }) {
                val has = state.sabright.name.isNotEmpty()
                Row(
                    Modifier.fillMaxWidth().clickable(enabled = has) { state.sabNi = !state.sabNi },
                    verticalAlignment = Alignment.Top
                ) {
                    Checkbox(
                        checked = state.sabNi,
                        onCheckedChange = { state.sabNi = it },
                        enabled = has,
                        colors = CheckboxDefaults.colors(checkedColor = Amber, checkmarkColor = Color(0xFF1A0E00), uncheckedColor = Muted)
                    )
                    Text(
                        "Tambahkan keterangan NI – berlaku Sabtu/Minggu (08:00–16:00 WIB)",
                        color = if (has) TextC else Muted.copy(alpha = 0.5f),
                        fontSize = 14.sp,
                        modifier = Modifier.weight(1f).padding(top = 12.dp)
                    )
                }
            }

            // ----- Cleaning Service -----
            PersonCard(state, "cs", "🧹", Teal, onManage = { manageRole = it })

            // ----- Security -----
            PersonCard(state, "security", "🛡️", Red, onManage = { manageRole = it })

            // ----- Foto & Video -----
            SectionCard(Purple) {
                CardHeader("📷", "Foto & Video", null)
                val photos = state.media.count { !MediaUtil.isVideo(it) }
                val videos = state.media.count { MediaUtil.isVideo(it) }
                Text(
                    if (state.media.isEmpty()) "Belum ada foto/video. Bisa menambah beberapa sekaligus."
                    else "$photos foto · $videos video",
                    color = Muted, fontSize = 13.sp
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MediaButton("🖼 Tambah Foto", Modifier.weight(1f)) {
                        pickPhotos.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }
                    MediaButton("🎞 Tambah Video", Modifier.weight(1f)) {
                        pickVideos.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MediaButton("📷 Ambil Foto", Modifier.weight(1f)) { startCapture(false) }
                    MediaButton("🎥 Rekam Video", Modifier.weight(1f)) { startCapture(true) }
                }
                if (importing) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Amber)
                        Spacer(Modifier.width(10.dp))
                        Text("Menyalin file…", color = Muted, fontSize = 13.sp)
                    }
                }
                state.media.toList().chunked(3).forEach { rowItems ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        rowItems.forEach { name ->
                            MediaThumb(name, imageLoader, Modifier.weight(1f), { openMedia(name) }, { deleteMedia = name })
                        }
                        repeat(3 - rowItems.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
                if (state.media.isNotEmpty()) {
                    Text("Ketuk untuk melihat · ✕ untuk menghapus", color = Muted, fontSize = 12.sp)
                }
            }

            // ----- Tombol -----
            Button(
                onClick = { report = generateReport(state) },
                modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Color(0xFF1A0E00))
            ) {
                Text("Buat Laporan Briefing", fontWeight = FontWeight.Bold, fontSize = 16.sp, textAlign = TextAlign.Center)
            }
            OutlinedButton(
                onClick = { confirmReset = true },
                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, BorderC),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Muted)
            ) {
                Text("Reset Form", textAlign = TextAlign.Center)
            }

            // ----- Hasil -----
            report?.let { text ->
                val shape = RoundedCornerShape(14.dp)
                Column(
                    Modifier
                        .fillMaxWidth()
                        .bringIntoViewRequester(bring)
                        .clip(shape)
                        .background(SurfaceC)
                        .border(1.dp, BorderC, shape)
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    CardHeader("📋", "Hasil Laporan", null)
                    SelectionContainer {
                        Text(
                            text,
                            color = TextC,
                            fontSize = 14.sp,
                            lineHeight = 20.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(Surface2)
                                .padding(12.dp)
                        )
                    }
                    Button(
                        onClick = { clipboard.setText(AnnotatedString(text)); copied = true },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, BorderC),
                        colors = ButtonDefaults.buttonColors(containerColor = Surface2, contentColor = TextC)
                    ) { Text(if (copied) "✅ Disalin!" else "📋 Salin Teks", textAlign = TextAlign.Center) }
                    Button(
                        onClick = { sendWhatsApp(text) },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366), contentColor = Color(0xFF06351E))
                    ) { Text("🟢 Kirim Teks ke WhatsApp", fontWeight = FontWeight.Bold, textAlign = TextAlign.Center) }
                    if (state.media.isNotEmpty()) {
                        Button(
                            onClick = { shareWithMedia(text) },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Blue, contentColor = Color.White)
                        ) {
                            Text(
                                "📤 Kirim Laporan + ${state.media.size} Foto/Video",
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }

            Text(
                "Briefing Shift · ${state.spbuName}",
                color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 16.dp)
            )
        }
    }

    // ----- Dialog -----
    manageRole?.let { role ->
        NameManager(state, role) { manageRole = null }
    }
    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Reset Form") },
            text = { Text("Reset semua isian form ke kondisi awal? Foto dan video yang sudah ditambahkan juga akan dihapus. Daftar nama tidak berubah.") },
            confirmButton = {
                TextButton(onClick = { state.resetForm(); report = null; confirmReset = false }) { Text("Reset", color = Red) }
            },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Batal") } },
            containerColor = SurfaceC, titleContentColor = TextC, textContentColor = Muted
        )
    }
    deleteMedia?.let { name ->
        AlertDialog(
            onDismissRequest = { deleteMedia = null },
            title = { Text(if (MediaUtil.isVideo(name)) "Hapus video?" else "Hapus foto?") },
            text = { Text("File ini akan dihapus dari aplikasi.") },
            confirmButton = {
                TextButton(onClick = { state.removeMedia(name); deleteMedia = null }) { Text("Hapus", color = Red) }
            },
            dismissButton = { TextButton(onClick = { deleteMedia = null }) { Text("Batal") } },
            containerColor = SurfaceC, titleContentColor = TextC, textContentColor = Muted
        )
    }
}

// =====================================================================
// KOMPONEN
// =====================================================================
@Composable
fun Header(state: AppState) {
    var nowMs by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            nowMs = System.currentTimeMillis()
            delay(1000)
        }
    }
    val c = Calendar.getInstance().apply { timeInMillis = nowMs }
    val dateStr = "${DAYS[c.get(Calendar.DAY_OF_WEEK) - 1]}, ${c.get(Calendar.DAY_OF_MONTH)} ${MONTHS[c.get(Calendar.MONTH)]} ${c.get(Calendar.YEAR)}"
    val timeStr = String.format(
        Locale.US, "%02d:%02d:%02d WIB",
        c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), c.get(Calendar.SECOND)
    )

    Column(
        Modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Surface2, Bg)))
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Image(
                painter = painterResource(R.drawable.app_icon),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .border(2.dp, Amber, RoundedCornerShape(12.dp))
            )
            Column(Modifier.weight(1f)) {
                Text("Briefing Shift", color = TextC, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                Text(state.spbuName, color = Muted, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF0A1424))
                .border(1.dp, BorderC, RoundedCornerShape(12.dp))
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(dateStr, color = Muted, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Spacer(Modifier.width(8.dp))
            Text(timeStr, color = Led, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}

@Composable
fun SectionCard(accent: Color, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(SurfaceC)
            .drawBehind { drawRect(accent, size = Size(4.dp.toPx(), size.height)) }
            .border(1.dp, BorderC, shape)
            .padding(start = 18.dp, end = 14.dp, top = 14.dp, bottom = 14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        content = content
    )
}

@Composable
fun Label(text: String) {
    Text(text, color = Muted, fontSize = 12.sp)
}

@Composable
fun CardHeader(icon: String, title: String, onManage: (() -> Unit)?) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(icon, fontSize = 20.sp)
        Text(title, color = TextC, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f))
        if (onManage != null) {
            OutlinedButton(
                onClick = onManage,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, BorderC),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Muted)
            ) { Text("⚙ Kelola Nama", fontSize = 12.sp) }
        }
    }
}

@Composable
fun PersonCard(
    state: AppState,
    role: String,
    icon: String,
    accent: Color,
    onManage: (String) -> Unit,
    extra: @Composable ColumnScope.() -> Unit = {}
) {
    val p = state.person(role)
    val title = ROLE_TITLES.getValue(role)
    SectionCard(accent) {
        CardHeader(icon, title) { onManage(role) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Dropdown(
                value = p.name,
                placeholder = "-- Pilih $title --",
                options = state.namesOf(role),
                onSelect = { state.setPerson(role, state.person(role).copy(name = it)) },
                modifier = Modifier.weight(1f)
            )
            TempField(p.temp, p.name.isNotEmpty()) { state.setPerson(role, state.person(role).copy(temp = it)) }
        }
        extra()
    }
}

@Composable
fun PramRowView(state: AppState, idx: Int, row: PramRow) {
    val used = state.pramuniaga.map { it.name }.filter { it.isNotEmpty() }
    val options = state.namesOf("pramuniaga").filter { it == row.name || it !in used }
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(Bg.copy(alpha = 0.35f))
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Dropdown(
            value = row.name,
            placeholder = "-- Pilih Pramuniaga --",
            options = options,
            onSelect = { state.setPramName(idx, it) },
            modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TempField(row.temp, row.name.isNotEmpty()) { state.updatePram(idx, row.copy(temp = it)) }
            if (state.pulauEnabled) {
                Dropdown(
                    value = row.pulau,
                    placeholder = "Pulau",
                    options = listOf("1", "2", "3", "4"),
                    onSelect = { state.updatePram(idx, row.copy(pulau = it)) },
                    modifier = Modifier.weight(1f),
                    label = { "P$it" }
                )
            } else {
                Spacer(Modifier.weight(1f))
            }
            if (row.name.isNotEmpty()) {
                TextButton(onClick = { state.removePram(idx) }) { Text("✕ Hapus", color = Red, fontSize = 13.sp) }
            }
        }
    }
}

@Composable
fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = TextC,
    unfocusedTextColor = TextC,
    disabledTextColor = Muted.copy(alpha = 0.5f),
    focusedContainerColor = Surface2,
    unfocusedContainerColor = Surface2,
    disabledContainerColor = Surface2,
    cursorColor = Amber,
    focusedBorderColor = Blue,
    unfocusedBorderColor = BorderC,
    disabledBorderColor = BorderC,
    focusedPlaceholderColor = Muted,
    unfocusedPlaceholderColor = Muted
)

@Composable
fun TempField(value: String, enabled: Boolean, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { v -> onChange(v.filter { it.isDigit() || it == '.' || it == ',' }.take(5)) },
        enabled = enabled,
        singleLine = true,
        suffix = { Text("°C", color = Muted) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        textStyle = LocalTextStyle.current.copy(textAlign = TextAlign.End),
        shape = RoundedCornerShape(10.dp),
        colors = fieldColors(),
        modifier = Modifier.width(116.dp)
    )
}

/** Dropdown: teks pilihan selalu tampil penuh (membungkus ke baris berikutnya, tidak dipotong). */
@Composable
fun Dropdown(
    value: String,
    placeholder: String,
    options: List<String>,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
    label: (String) -> String = { it }
) {
    var open by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(10.dp)
    Box(modifier) {
        Row(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 56.dp)
                .clip(shape)
                .background(Surface2)
                .border(1.dp, BorderC, shape)
                .clickable { open = true }
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                if (value.isEmpty()) placeholder else label(value),
                color = if (value.isEmpty()) Muted else TextC,
                fontSize = 16.sp,
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(6.dp))
            Text("▾", color = Muted)
        }
        DropdownMenu(
            expanded = open,
            onDismissRequest = { open = false },
            modifier = Modifier.background(Surface2)
        ) {
            DropdownMenuItem(
                text = { Text(placeholder, color = Muted) },
                onClick = { onSelect(""); open = false }
            )
            options.forEach { opt ->
                DropdownMenuItem(
                    text = { Text(label(opt), color = TextC) },
                    onClick = { onSelect(opt); open = false }
                )
            }
        }
    }
}

@Composable
fun MediaButton(text: String, modifier: Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier.heightIn(min = 48.dp),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, BorderC),
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Surface2, contentColor = TextC)
    ) { Text(text, fontSize = 14.sp, textAlign = TextAlign.Center) }
}

@Composable
fun MediaThumb(name: String, loader: ImageLoader, modifier: Modifier, onOpen: () -> Unit, onDelete: () -> Unit) {
    val ctx = LocalContext.current
    Box(
        modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(10.dp))
            .background(Surface2)
            .clickable { onOpen() }
    ) {
        AsyncImage(
            model = MediaUtil.file(ctx, name),
            imageLoader = loader,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        if (MediaUtil.isVideo(name)) {
            Box(
                Modifier
                    .align(Alignment.Center)
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.55f)),
                contentAlignment = Alignment.Center
            ) { Text("▶", color = Color.White, fontSize = 16.sp) }
        }
        Box(
            Modifier
                .align(Alignment.TopEnd)
                .padding(4.dp)
                .size(28.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.65f))
                .clickable { onDelete() },
            contentAlignment = Alignment.Center
        ) { Text("✕", color = Color.White, fontSize = 13.sp) }
    }
}

@Composable
fun NameManager(state: AppState, role: String, onClose: () -> Unit) {
    var input by remember { mutableStateOf("") }
    var pendingDelete by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val list = state.namesOf(role)

    fun add() {
        val v = input.trim().replace(Regex("\\s+"), " ")
        if (v.isEmpty()) return
        if (list.any { it.equals(v, ignoreCase = true) }) {
            error = "Nama sudah ada di daftar."
            return
        }
        state.setNames(role, list + v)
        input = ""
        error = null
    }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        val shape = RoundedCornerShape(18.dp)
        Column(
            Modifier
                .fillMaxWidth(0.94f)
                .fillMaxHeight(0.8f)
                .clip(shape)
                .background(SurfaceC)
                .border(1.dp, BorderC, shape)
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Kelola Nama – ${ROLE_TITLES[role]}",
                    color = TextC, fontWeight = FontWeight.Bold, fontSize = 16.sp,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = onClose) { Text("Tutup", color = Muted) }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it.take(40); error = null },
                    placeholder = { Text("Tambah nama baru...") },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    colors = fieldColors(),
                    modifier = Modifier.weight(1f)
                )
                Button(
                    onClick = { add() },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color(0xFF06231A))
                ) { Text("+ Tambah", fontWeight = FontWeight.Bold) }
            }
            error?.let { Text(it, color = Red, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)) }
            LazyColumn(
                Modifier.weight(1f).padding(top = 10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (list.isEmpty()) {
                    item { Text("Belum ada nama. Tambahkan di atas.", color = Muted, fontSize = 13.sp) }
                }
                items(list, key = { it }) { name ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Surface2)
                            .border(1.dp, BorderC, RoundedCornerShape(10.dp))
                            .padding(start = 12.dp, top = 4.dp, bottom = 4.dp, end = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(name, color = TextC, fontSize = 15.sp, modifier = Modifier.weight(1f))
                        TextButton(onClick = { pendingDelete = name }) { Text("🗑", fontSize = 16.sp) }
                    }
                }
            }
            Text(
                "Perubahan tersimpan permanen di perangkat ini.",
                color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
            )
        }
    }

    pendingDelete?.let { name ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("Hapus nama?") },
            text = { Text("Hapus \"$name\" dari daftar?") },
            confirmButton = {
                TextButton(onClick = { state.setNames(role, list - name); pendingDelete = null }) { Text("Hapus", color = Red) }
            },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("Batal") } },
            containerColor = SurfaceC, titleContentColor = TextC, textContentColor = Muted
        )
    }
}
