# Briefing Shift SPBU (Android Native, Kotlin + Jetpack Compose)

Port dari PWA "Briefing Shift" SPBU COCO 31.107.02 Samanhudi, ditambah fitur
tambah banyak foto & video (galeri atau kamera) yang bisa dikirim bersama laporan.

Build: push ke GitHub -> tab Actions -> "Build APK" -> APK ada di Releases.
